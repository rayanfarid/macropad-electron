const OPENAI_API_BASE = "https://api.openai.com/v1";
const DEFAULT_AI_MODEL = "gpt-4.1-mini";

function assertApiKeyShape(apiKey) {
  if (typeof apiKey !== "string" || !/^sk-[A-Za-z0-9_-]{16,240}$/.test(apiKey)) {
    throw new Error("The saved OpenAI API key looks invalid. Update it in Settings → AI Assistance.");
  }
}

function redactSecrets(text) {
  return String(text || "")
    .replace(/Bearer\s+[A-Za-z0-9._-]+/gi, "Bearer [redacted]")
    .replace(/sk-[A-Za-z0-9_-]{10,}/g, "[redacted-api-key]");
}

function sanitizeThrownMessage(message) {
  return redactSecrets(message).slice(0, 600);
}

async function readOpenAiErrorDetails(response) {
  const details = { status: response.status, message: "", type: "", code: "" };
  try {
    const body = await response.json();
    const error = body?.error || body || {};
    details.message = typeof error.message === "string" ? error.message : "";
    details.type = typeof error.type === "string" ? error.type : "";
    details.code = typeof error.code === "string" || typeof error.code === "number" ? String(error.code) : "";
  } catch {
    try {
      const text = await response.text();
      details.message = typeof text === "string" ? text.slice(0, 400) : "";
    } catch {}
  }
  details.message = sanitizeThrownMessage(details.message);
  details.type = sanitizeThrownMessage(details.type);
  details.code = sanitizeThrownMessage(details.code);
  return details;
}

function logOpenAiFailure(context, details, model) {
  console.error("[openai]", JSON.stringify({
    context,
    status: details.status,
    type: details.type || null,
    code: details.code || null,
    message: details.message || null,
    model: model || null
  }));
}

function formatOpenAiHttpError(details, { model, operation = "request" } = {}) {
  const status = details.status;
  const apiMessage = details.message || "No error message was returned.";
  if (status === 401) {
    return sanitizeThrownMessage("OpenAI rejected this API key. Check the key in Settings → AI Assistance.");
  }
  if (status === 403) {
    return sanitizeThrownMessage(`OpenAI rejected the ${operation}: ${apiMessage}`);
  }
  if (status === 404 && model) {
    return sanitizeThrownMessage(`OpenAI model "${model}" is not available for this API key. ${apiMessage}`);
  }
  if (status === 429) {
    return sanitizeThrownMessage(`OpenAI rate-limited the ${operation}: ${apiMessage}`);
  }
  return sanitizeThrownMessage(`OpenAI rejected the ${operation} (HTTP ${status}, model ${model || "unknown"}): ${apiMessage}`);
}

function buildScreenDesignRequest({ model, instructions, prompt, currentDesign }) {
  if (typeof model !== "string" || !model.trim()) throw new Error("AI model is not configured.");
  if (typeof prompt !== "string" || prompt.trim().length < 2) throw new Error("Describe the screen design in 2–3000 characters");
  // Responses API json_object mode requires the word "json" in an input message.
  // Top-level `instructions` alone does not satisfy that validation and yields HTTP 400.
  const userContent = [
    "Return one JSON object only.",
    "The JSON must include explanation (string), notes (string array), and design.",
    `Request: ${prompt.trim()}`,
    `Current supported design JSON: ${JSON.stringify(currentDesign)}`
  ].join("\n");
  return {
    url: `${OPENAI_API_BASE}/responses`,
    method: "POST",
    headers: {
      Authorization: "Bearer [redacted-in-builder]",
      "Content-Type": "application/json"
    },
    body: {
      model,
      instructions,
      input: [{ role: "user", content: userContent }],
      max_output_tokens: 4000,
      text: { format: { type: "json_object" } }
    }
  };
}

function extractResponsesOutputText(payload) {
  if (!payload || typeof payload !== "object") throw new Error("AI response did not contain a design");
  if (typeof payload.output_text === "string" && payload.output_text.trim()) return payload.output_text;
  const texts = [];
  for (const item of payload.output || []) {
    for (const part of item?.content || []) {
      if (part?.type === "output_text" && typeof part.text === "string") texts.push(part.text);
    }
  }
  const joined = texts.join("\n").trim();
  if (!joined) throw new Error("AI response did not contain a design");
  return joined;
}

async function testOpenAiConnection(apiKey, options = {}) {
  const fetchImpl = options.fetchImpl || fetch;
  const model = options.model || DEFAULT_AI_MODEL;
  assertApiKeyShape(apiKey);

  let response;
  try {
    response = await fetchImpl(`${OPENAI_API_BASE}/models`, {
      method: "GET",
      headers: { Authorization: `Bearer ${apiKey}` },
      signal: AbortSignal.timeout(15000)
    });
  } catch (error) {
    throw new Error(error?.name === "TimeoutError"
      ? "OpenAI connection timed out. Check your internet connection and try again."
      : "Could not reach OpenAI. Check your internet connection and try again.");
  }

  if (!response.ok) {
    const details = await readOpenAiErrorDetails(response);
    logOpenAiFailure("test-connection/models", details, model);
    throw new Error(formatOpenAiHttpError(details, { model, operation: "connection test" }));
  }

  let modelResponse;
  try {
    modelResponse = await fetchImpl(`${OPENAI_API_BASE}/models/${encodeURIComponent(model)}`, {
      method: "GET",
      headers: { Authorization: `Bearer ${apiKey}` },
      signal: AbortSignal.timeout(15000)
    });
  } catch (error) {
    throw new Error(error?.name === "TimeoutError"
      ? "OpenAI connection timed out while checking the configured model."
      : "Could not reach OpenAI while checking the configured model.");
  }

  if (!modelResponse.ok) {
    const details = await readOpenAiErrorDetails(modelResponse);
    logOpenAiFailure("test-connection/model", details, model);
    throw new Error(formatOpenAiHttpError(details, { model, operation: "model check" }));
  }

  return {
    success: true,
    message: `AI connection successful. Model "${model}" is available for this API key.`,
    model
  };
}

async function generateScreenDesignWithOpenAi({
  apiKey,
  model,
  instructions,
  prompt,
  currentDesign,
  fetchImpl = fetch,
  parseResponse
}) {
  assertApiKeyShape(apiKey);
  if (typeof parseResponse !== "function") throw new Error("AI response parser is missing");
  const request = buildScreenDesignRequest({ model, instructions, prompt, currentDesign });
  let response;
  try {
    response = await fetchImpl(request.url, {
      method: request.method,
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      signal: AbortSignal.timeout(45000),
      body: JSON.stringify(request.body)
    });
  } catch (error) {
    throw new Error(error?.name === "TimeoutError"
      ? "OpenAI generation timed out. Try again."
      : "Could not reach OpenAI to generate a screen design.");
  }

  if (!response.ok) {
    const details = await readOpenAiErrorDetails(response);
    logOpenAiFailure("generate-screen", details, model);
    throw new Error(formatOpenAiHttpError(details, { model, operation: "screen generation" }));
  }

  let payload;
  try {
    payload = await response.json();
  } catch {
    throw new Error("OpenAI returned a malformed JSON response.");
  }

  const output = extractResponsesOutputText(payload);
  return parseResponse(output);
}

module.exports = {
  OPENAI_API_BASE,
  DEFAULT_AI_MODEL,
  assertApiKeyShape,
  redactSecrets,
  sanitizeThrownMessage,
  readOpenAiErrorDetails,
  formatOpenAiHttpError,
  buildScreenDesignRequest,
  extractResponsesOutputText,
  testOpenAiConnection,
  generateScreenDesignWithOpenAi
};
