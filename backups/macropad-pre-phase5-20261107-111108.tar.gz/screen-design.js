const SCREEN_WIDTH = 128;
const SCREEN_HEIGHT = 64;
const SCREEN_DESIGN_VERSION = 2;
const MAX_SCREEN_ELEMENTS = 8;
const MAX_SCREEN_PAGES = 8;
const BINDINGS = new Set(["STATIC", "HOST", "LAST", "ENCODER", "HID", "KEYGRID"]);
const ALIGNMENTS = new Set(["LEFT", "CENTER", "RIGHT"]);
const MODES = new Set(["NORMAL", "INVERSE"]);

function defaultElements() {
  return [
    { id: "key-grid", x: 4, y: 1, size: 1, mode: "NORMAL", alignment: "LEFT", binding: "KEYGRID", text: "" },
    { id: "host", x: 74, y: 2, size: 1, mode: "INVERSE", alignment: "LEFT", binding: "HOST", text: "" },
    { id: "last-label", x: 72, y: 20, size: 1, mode: "NORMAL", alignment: "LEFT", binding: "STATIC", text: "Last:" },
    { id: "last", x: 72, y: 31, size: 1, mode: "NORMAL", alignment: "LEFT", binding: "LAST", text: "" },
    { id: "encoder", x: 72, y: 44, size: 1, mode: "NORMAL", alignment: "LEFT", binding: "ENCODER", text: "" },
    { id: "hid", x: 72, y: 55, size: 1, mode: "NORMAL", alignment: "LEFT", binding: "HID", text: "" }
  ];
}

function createDefaultScreenPage(index = 0) {
  return { id: `screen-page-${index + 1}`, name: `Page ${index + 1}`, elements: defaultElements() };
}

function createDefaultScreenDesign() {
  return { version: SCREEN_DESIGN_VERSION, pages: [createDefaultScreenPage()] };
}

function validateElements(elements) {
  if (!Array.isArray(elements) || elements.length > MAX_SCREEN_ELEMENTS) throw new Error(`Each OLED page supports at most ${MAX_SCREEN_ELEMENTS} elements`);
  const ids = new Set();
  return elements.map((element, index) => {
    if (!element || typeof element !== "object" || Array.isArray(element)) throw new Error(`Screen element ${index + 1} is invalid`);
    if (Object.keys(element).some(key => !["id", "x", "y", "size", "mode", "alignment", "binding", "text"].includes(key))) throw new Error(`Screen element ${index + 1} contains an unsupported property`);
    const { id, x, y, size, mode, alignment, binding, text } = element;
    if (typeof id !== "string" || !/^[a-z0-9-]{1,24}$/i.test(id) || ids.has(id)) throw new Error(`Screen element ${index + 1} has an invalid or duplicate ID`);
    ids.add(id);
    if (!Number.isInteger(x) || !Number.isInteger(y) || x < 0 || x >= SCREEN_WIDTH || y < 0 || y >= SCREEN_HEIGHT) throw new Error(`Position for ${id} is outside the 128×64 display`);
    if (size !== 1 && size !== 2) throw new Error(`Font size for ${id} must be 1 or 2`);
    if (!MODES.has(mode) || !ALIGNMENTS.has(alignment) || !BINDINGS.has(binding)) throw new Error(`Unsupported rendering option for ${id}`);
    if (typeof text !== "string" || text.length > 21 || /[^\x20-\x7e]/.test(text) || /[\r\n]/.test(text)) throw new Error(`Text for ${id} must be at most 21 printable ASCII characters`);
    if (binding === "KEYGRID") {
      if (size !== 1 || mode !== "NORMAL" || alignment !== "LEFT" || x + 62 > SCREEN_WIDTH || y + 62 > SCREEN_HEIGHT) throw new Error(`Key grid for ${id} must fit its fixed 62×62 monochrome widget`);
      return { id, x, y, size, mode, alignment, binding, text };
    }
    const shownText = binding === "STATIC" ? text : binding === "HOST" ? "Omarchy" : binding === "HID" ? "HID OFF" : text || "WWWWWWWW";
    const width = shownText.length * 6 * size;
    const left = alignment === "CENTER" ? x - Math.floor(width / 2) : alignment === "RIGHT" ? x - width : x;
    if (left < 0 || left + width > SCREEN_WIDTH || y + 8 * size > SCREEN_HEIGHT) throw new Error(`Text for ${id} does not fit on the 128×64 display`);
    return { id, x, y, size, mode, alignment, binding, text };
  });
}

function validateScreenPage(input, index = 0) {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw new Error(`OLED page ${index + 1} is invalid`);
  if (Object.keys(input).some(key => !["id", "name", "elements"].includes(key))) throw new Error(`OLED page ${index + 1} contains an unsupported property`);
  const id = input.id ?? `screen-page-${index + 1}`;
  const name = input.name ?? `Page ${index + 1}`;
  if (typeof id !== "string" || !/^[a-z0-9-]{1,24}$/i.test(id)) throw new Error(`Page ${index + 1} has an invalid ID`);
  if (typeof name !== "string" || name.length < 1 || name.length > 20 || /[^\x20-\x7e]/.test(name)) throw new Error(`Page ${index + 1} name must be 1–20 printable ASCII characters`);
  return { id, name, elements: validateElements(input.elements) };
}

function validateScreenDesign(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw new Error("Screen design must be an object");
  if (input.version === 1 && Array.isArray(input.elements)) {
    if (Object.keys(input).some(key => !["version", "elements"].includes(key))) throw new Error("Screen design contains an unsupported property");
    return { version: SCREEN_DESIGN_VERSION, pages: [validateScreenPage({ id: "screen-page-1", name: "Page 1", elements: input.elements })] };
  }
  if (input.version !== SCREEN_DESIGN_VERSION) throw new Error(`Unsupported screen design version: ${input.version}`);
  if (Object.keys(input).some(key => !["version", "pages"].includes(key))) throw new Error("Screen design contains an unsupported property");
  if (!Array.isArray(input.pages) || input.pages.length < 1 || input.pages.length > MAX_SCREEN_PAGES) throw new Error(`OLED designs must contain 1–${MAX_SCREEN_PAGES} pages`);
  const ids = new Set();
  const pages = input.pages.map((page, index) => {
    const valid = validateScreenPage(page, index);
    if (ids.has(valid.id)) throw new Error(`Duplicate OLED page ID: ${valid.id}`);
    ids.add(valid.id);
    return valid;
  });
  return { version: SCREEN_DESIGN_VERSION, pages };
}

function encodeText(text) {
  return text ? Array.from(text, char => char.charCodeAt(0).toString(16).padStart(2, "0")).join("") : "-";
}

function screenItemCommand(element, index) {
  const valid = validateElements([element])[0];
  return `SCREEN ITEM ${index} ${valid.x} ${valid.y} ${valid.size} ${valid.mode} ${valid.binding} ${valid.alignment} ${encodeText(valid.text)}`;
}

function buildScreenUploadCommands(input) {
  const design = validateScreenDesign(input);
  if (design.pages.length !== 1) throw new Error("Use buildScreenPagesUploadCommands for multi-page designs");
  return ["SCREEN BEGIN", "SCREEN CLEAR", ...design.pages[0].elements.map(screenItemCommand), "SCREEN VALIDATE", "SCREEN COMMIT"];
}

function buildScreenPagesUploadCommands(input) {
  const design = validateScreenDesign(input);
  const commands = ["SCREEN PAGES BEGIN", "SCREEN PAGES CLEAR"];
  design.pages.forEach((page, pageIndex) => {
    commands.push(`SCREEN PAGE ADD ${pageIndex} ${encodeText(page.name)}`);
    page.elements.forEach((element, elementIndex) => {
      const item = screenItemCommand(element, elementIndex).replace(/^SCREEN ITEM /, "");
      commands.push(`SCREEN PAGE ITEM ${pageIndex} ${item}`);
    });
  });
  commands.push("SCREEN PAGES VALIDATE", "SCREEN PAGES COMMIT");
  return commands;
}

function decodeText(value) {
  if (value === "-") return "";
  if (!/^(?:[0-9a-f]{2})*$/i.test(value)) throw new Error("Screen text encoding is invalid");
  const decoded = (value.match(/.{2}/g) || []).map(pair => String.fromCharCode(parseInt(pair, 16))).join("");
  if (/[^\x20-\x7e]/.test(decoded)) throw new Error("Screen text is not printable ASCII");
  return decoded;
}

function parseScreenItemLine(line, idPrefix = "device") {
  const match = line.match(/^SCREEN ITEM (\d+) (\d+) (\d+) ([12]) (NORMAL|INVERSE) (STATIC|HOST|LAST|ENCODER|HID|KEYGRID) (LEFT|CENTER|RIGHT) ([0-9a-f]*|-)$/i);
  if (!match) return null;
  const [, index, x, y, size, mode, binding, alignment, rawText] = match;
  return { index: Number(index), element: {
    id: `${idPrefix}-${index}`, x: Number(x), y: Number(y), size: Number(size), mode: mode.toUpperCase(),
    binding: binding.toUpperCase(), alignment: alignment.toUpperCase(), text: decodeText(rawText)
  } };
}

function parseScreenGet(lines) {
  if (lines.some(raw => ["SCREEN LEGACY", "ERR unknown command"].includes(String(raw).trim()))) return { supported: false, design: null };
  const elements = [];
  for (const raw of lines) {
    const parsed = parseScreenItemLine(String(raw).trim());
    if (parsed) elements[parsed.index] = parsed.element;
  }
  return { supported: true, design: validateScreenDesign({ version: SCREEN_DESIGN_VERSION, pages: [{ id: "screen-page-1", name: "Page 1", elements: elements.filter(Boolean) }] }) };
}

function parseScreenPagesGet(lines) {
  const normalized = lines.map(raw => String(raw).trim());
  if (normalized.some(line => ["ERR unknown command", "ERR unknown SCREEN command"].includes(line))) return { supported: false, design: null };
  const countLine = normalized.find(line => /^SCREEN PAGES \d+$/.test(line));
  if (!countLine) return { supported: false, design: null };
  const pageCount = Number(countLine.split(" ")[2]);
  const currentLine = normalized.find(line => /^SCREEN CURRENT \d+$/.test(line));
  const currentPageNumber = currentLine ? Number(currentLine.split(" ")[2]) : 0;
  const pages = [];
  let currentPage = null;
  for (const line of normalized) {
    const pageMatch = line.match(/^SCREEN PAGE (\d+) ([0-9a-f]*|-)$/i);
    if (pageMatch) {
      currentPage = Number(pageMatch[1]);
      pages[currentPage] = { id: `device-page-${currentPage + 1}`, name: decodeText(pageMatch[2]), elements: [] };
      continue;
    }
    if (line === "SCREEN PAGE END") { currentPage = null; continue; }
    if (currentPage !== null) {
      const item = parseScreenItemLine(line, `device-p${currentPage + 1}-item`);
      if (item) pages[currentPage].elements[item.index] = item.element;
    }
  }
  if (pageCount < 1 || pageCount > MAX_SCREEN_PAGES || currentPageNumber >= pageCount || pages.filter(Boolean).length !== pageCount) throw new Error("Device returned an invalid OLED page list");
  return { supported: true, multiPageSupported: true, currentPage: currentPageNumber, design: validateScreenDesign({ version: SCREEN_DESIGN_VERSION, pages: pages.map(page => ({ ...page, elements: page.elements.filter(Boolean) })) }) };
}

function parseCurrentScreenPage(lines) {
  const match = lines.map(raw => String(raw).trim()).map(line => line.match(/^SCREEN CURRENT (\d+)$/)).find(Boolean);
  if (!match) throw new Error("Device did not report the current OLED page");
  return Number(match[1]);
}

function nextScreenPageIndex(currentPage, pageCount) {
  if (!Number.isInteger(pageCount) || pageCount < 1 || pageCount > MAX_SCREEN_PAGES) throw new Error("OLED page count is invalid");
  if (!Number.isInteger(currentPage) || currentPage < 0 || currentPage >= pageCount) throw new Error("Current OLED page is invalid");
  return (currentPage + 1) % pageCount;
}

module.exports = {
  SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_DESIGN_VERSION, MAX_SCREEN_ELEMENTS, MAX_SCREEN_PAGES,
  createDefaultScreenPage, createDefaultScreenDesign, validateScreenPage, validateScreenDesign,
  screenItemCommand, buildScreenUploadCommands, buildScreenPagesUploadCommands,
  parseScreenGet, parseScreenPagesGet, parseCurrentScreenPage, nextScreenPageIndex
};
