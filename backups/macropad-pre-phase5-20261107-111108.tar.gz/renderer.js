const BUTTON_SLOTS = ["1", "2", "3", "4", "5", "6", "7", "8", "9"];
const ENCODER_SLOTS = ["CW", "CCW", "PRESS"];
const HOSTS = ["WINDOWS", "LINUX", "MACOS", "OMARCHY"];
const HOST_LABELS = { WINDOWS: "Windows", LINUX: "Linux", MACOS: "macOS", OMARCHY: "Omarchy" };
const PAGE_LABELS = {
  dashboard: ["MACROPAD CONTROL", "Dashboard"],
  buttons: ["PHYSICAL KEY CONFIGURATION", "Button editor"],
  encoder: ["ROTARY CONTROL", "Encoder settings"],
  layout: ["LOCAL APPEARANCE", "Layout editor"],
  screen: ["OLED DESIGN", "Screen designer"],
  settings: ["APPLICATION", "Settings"]
};
const SLOT_TITLES = { CW: "Clockwise", CCW: "Counterclockwise", PRESS: "Encoder press" };
const DEFAULT_ACTIONS = Object.fromEntries([...BUTTON_SLOTS, ...ENCODER_SLOTS].map(slot => [slot, "NONE"]));

let config = null;
let configLoaded = false;
let configLoadTask = null;
let persistTimer = null;
let connection = { connected: false };
let connectionInfo = { ports: [] };
let syncState = { state: "disconnected", detail: "" };
let lastSyncAt = null;
let selectedSlot = "1";
let selectedLayoutSlot = "1";
let layoutDraft = null;
let layoutEditing = false;
let importPreview = null;
let queuedDiscovery = undefined;
let selectedScreenElement = 0;
let selectedScreenPage = 0;
let pendingAiDesign = null;
let screenHistory = [];
let screenHistoryIndex = -1;
let screenPreviewMode = false;
let screenDrag = false;
let aiKeyConfigured = false;
let pendingScreenImport = null;
const unsubscribeEvents = [];

const $ = id => document.getElementById(id);

function activeScreenPage(design = config?.screenDesign) {
  if (!design?.pages?.length) return null;
  selectedScreenPage = Math.max(0, Math.min(selectedScreenPage, design.pages.length - 1));
  return design.pages[selectedScreenPage];
}

function screenElements(design = config?.screenDesign) { return activeScreenPage(design)?.elements || []; }

function selectScreenPageIndex(index, { pushHistory = false } = {}) {
  if (!config?.screenDesign?.pages?.length) return;
  const next = Math.max(0, Math.min(index, config.screenDesign.pages.length - 1));
  if (next === selectedScreenPage) { renderScreenPages(); return; }
  selectedScreenPage = next;
  selectedScreenElement = 0;
  if (pushHistory) pushScreenHistory();
  renderScreenPages();
  renderScreenInspector();
  renderButtonEditor();
  renderDashboard();
}

function renderScreenPages() {
  const select = $("screenPageSelect");
  if (!select || !config) return;
  selectedScreenPage = Math.max(0, Math.min(selectedScreenPage, config.screenDesign.pages.length - 1));
  select.replaceChildren(...config.screenDesign.pages.map((page, index) => {
    const option = document.createElement("option"); option.value = String(index); option.textContent = page.name || `Page ${index + 1}`; return option;
  }));
  select.value = String(selectedScreenPage);
  $("screenPageCount").textContent = `Page ${selectedScreenPage + 1} / ${config.screenDesign.pages.length}`;
  $("screenDeletePageButton").disabled = config.screenDesign.pages.length <= 1;
  $("screenShowPageButton").disabled = !connection.connected;
  $("screenDuplicatePageButton").disabled = config.screenDesign.pages.length >= 8;
  $("screenAddPageButton").disabled = config.screenDesign.pages.length >= 8;
  $("screenPrevPageButton").disabled = config.screenDesign.pages.length <= 1 || selectedScreenPage <= 0;
  $("screenNextPageButton").disabled = config.screenDesign.pages.length <= 1 || selectedScreenPage >= config.screenDesign.pages.length - 1;
  $("sw9PageHint").textContent = config.screenDesign.pages.length > 1
    ? "Multiple pages enabled: physical SW9 switches pages on the ESP32, even while the PC is disconnected. Its saved macro assignments resume when one page remains."
    : "One OLED page: physical SW9 keeps its normal macro assignment.";
}

function addScreenPage({ duplicate = false } = {}) {
  if (config.screenDesign.pages.length >= 8) { toast("The firmware supports up to eight OLED pages.", true); return; }
  const hasSw9Assignment = Object.values(config.profiles).some(profile => profile["9"] && profile["9"] !== "NONE");
  if (config.screenDesign.pages.length === 1) {
    const detail = hasSw9Assignment ? " Existing SW9 macro assignments for all host profiles will remain saved and resume when you upload a one-page design." : " SW9's normal macro assignment remains available when you upload a one-page design.";
    if (!window.confirm(`Multiple OLED pages enabled. Physical SW9 (slot 9) will become Next OLED Page after upload and wrap from the last page to Page 1.${detail} Continue?`)) return;
  }
  const source = duplicate ? activeScreenPage() : null;
  const index = config.screenDesign.pages.length;
  config.screenDesign.pages.push(source
    ? { id: `screen-page-${Date.now().toString(36)}`, name: `Page ${index + 1}`, elements: clone(source.elements) }
    : { id: `screen-page-${Date.now().toString(36)}`, name: `Page ${index + 1}`, elements: [] });
  selectedScreenPage = index; selectedScreenElement = Math.max(0, screenElements().length - 1);
  pushScreenHistory(); renderScreenPages(); renderScreenInspector(); renderButtonEditor(); renderDashboard();
}

function tooltipName(element) {
  const id = element.id || "";
  const names = {
    screenUndoButton: "Undo — Revert the last change",
    screenRedoButton: "Redo — Restore the change you just undid",
    screenAddButton: "Add Element — Add a new item to the OLED screen",
    screenDuplicateButton: "Duplicate Element — Copy the selected screen item",
    screenPreviewButton: "Preview — See how the OLED screen will look",
    screenReadButton: "Read from Device — Load the current configuration from the ESP32",
    screenUploadButton: "Upload to Device — Send this configuration to the ESP32",
    screenSaveButton: "Save — Save this configuration locally",
    screenImportButton: "Import — Load a previously exported configuration",
    screenExportButton: "Export — Save this configuration as a file",
    screenAddPageButton: "Add Page — Add another OLED screen page (up to 8)",
    screenDuplicatePageButton: "Duplicate Page — Copy the selected OLED page",
    screenDeletePageButton: "Delete Page — Remove the selected page; the final page cannot be deleted",
    screenPrevPageButton: "Previous Page — Edit the previous OLED page design",
    screenNextPageButton: "Next Page — Edit the next OLED page design",
    screenShowPageButton: "Show on Device — Display this page on the connected ESP32 OLED",
    screenAiGenerateButton: "Generate with AI — Describe what you want and let AI create a screen layout",
    applyAiDesignButton: "Apply — Replace the local screen design with the AI preview (does not upload)",
    cancelAiDesignButton: "Cancel — Discard the AI-generated preview",
    openAiSettingsButton: "Open AI Settings — Go to Settings → AI Assistance",
    saveAiKeyButton: "Save API Key — Encrypt and store the key in Electron's secure storage",
    testAiConnectionButton: "Test Connection — Make a minimal authenticated request to OpenAI",
    clearAiKeyButton: "Remove — Delete the encrypted API key from this app",
    toggleAiKeyButton: "Show/Hide API key — Reveal or mask the key you entered",
    aiEnabledToggle: "Enable AI Assistance — Allow explicit AI generation and connection tests",
    aiKeyInput: "OpenAI API Key — Paste your secret key here; it stays in the main process after saving",
    screenCanvas: "OLED preview — Drag elements to reposition them on the 128×64 display",
    connectButton: "Connect — Find and connect to the ESP32 Macropad",
    disconnectButton: "Disconnect — Close the serial connection",
    reloadDeviceButton: "Read from Device — Load the current configuration from the ESP32",
    saveDeviceButton: "Upload to Device — Send this configuration to the ESP32",
    resetDeviceButton: "Reset Device — Restore ESP32 macro defaults after confirmation",
    exportButton: "Export — Save this configuration as a file",
    importButton: "Import — Load a previously exported configuration",
    editLayoutButton: "Edit layout — Rearrange visual key positions without changing firmware slots",
    saveLayoutButton: "Save layout — Keep the visual arrangement locally",
    cancelLayoutButton: "Cancel — Discard unsaved visual layout changes",
    resetLayoutButton: "Reset layout — Restore the default 3×3 visual arrangement",
    clearShortcutButton: "Clear assignment — Set this slot's shortcut to NONE",
    restoreButtonDefault: "Restore slot defaults — Clear the label and shortcut for this physical slot",
    clearActivityButton: "Clear log — Remove activity messages from this panel",
    refreshDeviceInfoButton: "Refresh device details — Re-read connected serial port information",
    restoreUiButton: "Restore application UI defaults — Reset theme, spacing, and visual layout only",
    screenDeleteButton: "Delete element — Remove the selected item from this OLED page"
  };
  if (element.dataset.tooltip) return element.dataset.tooltip;
  if (names[id]) return names[id];
  if (element.matches(".key-button")) {
    const slot = element.dataset.slot;
    if (slot === "9" && config?.screenDesign?.pages?.length > 1) {
      return "SW9 — Physical Slot 9 acts as Next OLED Page while multiple pages are enabled";
    }
    return element.dataset.tooltip || "Physical button — Select this firmware slot to edit its settings";
  }
  if (element.matches(".nav-item")) return `${element.textContent.trim()} — Open this section`;
  if (element.matches("#hostSelect")) return "Host Profile — Choose which operating system's shortcuts you are editing";
  if (element.matches("#screenPageSelect")) return "OLED Page — Select which independent screen layout to edit";
  if (element.matches("input,select,textarea")) {
    const label = element.labels?.[0]?.innerText?.trim() || element.getAttribute("aria-label") || element.placeholder || id;
    if (!label || label === id) return "";
    return `${label.split("\n")[0].trim()} — Edit this setting`;
  }
  if (element.matches("button.icon-button,button.text-button")) {
    return `${element.getAttribute("aria-label") || element.textContent.trim() || "Control"} — Activate this control`;
  }
  if (element.matches("button,[role=button],canvas")) {
    const label = element.getAttribute("aria-label") || element.textContent.trim();
    return label ? `${label} — Activate or edit this control` : "";
  }
  return "";
}

function initializeTooltips() {
  const tooltip = $("appTooltip");
  let timer = null;
  let active = null;
  const interactive = "button,input,select,textarea,canvas,.nav-item,[role=button]";
  const hide = () => {
    clearTimeout(timer);
    tooltip.hidden = true;
    if (active) active.removeAttribute("aria-describedby");
    active = null;
  };
  const place = target => {
    tooltip.textContent = tooltipName(target);
    if (!tooltip.textContent) { hide(); return; }
    tooltip.hidden = false;
    const rect = target.getBoundingClientRect();
    tooltip.style.left = `${Math.max(8, Math.min(innerWidth - tooltip.offsetWidth - 8, rect.left + rect.width / 2 - tooltip.offsetWidth / 2))}px`;
    tooltip.style.top = `${Math.max(8, Math.min(innerHeight - tooltip.offsetHeight - 8, rect.bottom + 8))}px`;
  };
  const show = target => {
    const text = tooltipName(target);
    if (!text) return;
    clearTimeout(timer);
    active = target;
    target.setAttribute("aria-describedby", "appTooltip");
    timer = setTimeout(() => {
      if (!active || !active.isConnected) return;
      place(active);
    }, 400);
  };
  document.addEventListener("pointerover", event => {
    const target = event.target.closest(interactive);
    if (!target) return;
    if (active === target) return;
    show(target);
  });
  document.addEventListener("pointerout", event => {
    const target = event.target.closest(interactive);
    if (!target || target !== active) return;
    const next = event.relatedTarget?.closest?.(interactive);
    if (next === active) return;
    hide();
  });
  document.addEventListener("focusin", event => {
    if (event.target.matches(interactive)) show(event.target);
  });
  document.addEventListener("focusout", event => {
    if (event.target.matches(interactive)) hide();
  });
  document.addEventListener("keydown", event => { if (event.key === "Escape") hide(); });
}

function log(message) {
  const line = `[${new Date().toLocaleTimeString()}] ${message}`;
  const logElement = $("activityLog");
  logElement.textContent += `${line}\n`;
  logElement.scrollTop = logElement.scrollHeight;
}

function toast(message, isError = false) {
  const element = $("toast");
  element.textContent = message;
  element.classList.toggle("error", isError);
  element.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { element.hidden = true; }, 6000);
}

function formatError(error) {
  return error && error.message ? error.message : String(error);
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function createDefaultLayout() {
  const positions = {};
  BUTTON_SLOTS.forEach((slot, index) => {
    positions[slot] = { row: Math.floor(index / 3), column: index % 3, rowSpan: 1, columnSpan: 1 };
  });
  return { rows: 3, columns: 3, positions };
}

function validateLayout(layout) {
  if (!layout || layout.rows !== 3 || layout.columns !== 3 || !layout.positions) throw new Error("Layout must be a 3×3 grid");
  if (Object.keys(layout.positions).length !== BUTTON_SLOTS.length || BUTTON_SLOTS.some(slot => !layout.positions[slot])) {
    throw new Error("Layout must contain all nine physical button slots");
  }
  const occupied = new Set();
  for (const slot of BUTTON_SLOTS) {
    const position = layout.positions[slot];
    const { row, column, rowSpan = 1, columnSpan = 1 } = position;
    if (![row, column, rowSpan, columnSpan].every(Number.isInteger) || row < 0 || column < 0 || rowSpan < 1 || columnSpan < 1 || row + rowSpan > 3 || column + columnSpan > 3) {
      throw new Error(`Visual size or position for SW${slot} is outside the 3×3 grid`);
    }
    for (let r = row; r < row + rowSpan; r++) for (let c = column; c < column + columnSpan; c++) {
      const cell = `${r}:${c}`;
      if (occupied.has(cell)) throw new Error("That visual change would overlap another key");
      occupied.add(cell);
    }
  }
  return clone(layout);
}

function swapLayoutSlots(layout, firstSlot, secondSlot) {
  const next = validateLayout(layout);
  if (!next.positions[firstSlot] || !next.positions[secondSlot]) throw new Error("Unknown physical key");
  const first = next.positions[firstSlot];
  const second = next.positions[secondSlot];
  next.positions[firstSlot] = { ...first, row: second.row, column: second.column };
  next.positions[secondSlot] = { ...second, row: first.row, column: first.column };
  return validateLayout(next);
}

function resizeLayoutSlot(layout, slot, rowSpan, columnSpan) {
  const next = validateLayout(layout);
  if (!next.positions[slot]) throw new Error(`Unknown physical key: ${slot}`);
  next.positions[slot] = { ...next.positions[slot], rowSpan, columnSpan };
  return validateLayout(next);
}

function mergeDeviceConfig(deviceConfig, previous) {
  const next = clone(previous);
  if (HOSTS.includes(deviceConfig.host)) next.host = deviceConfig.host;
  next.deviceWritePending = false;
  next.labels = Object.fromEntries([...BUTTON_SLOTS, ...ENCODER_SLOTS].map(slot => [slot, String(deviceConfig.labels?.[slot] ?? "").slice(0, 8)]));
  next.profiles = Object.fromEntries(HOSTS.map(host => [host,
    Object.fromEntries([...BUTTON_SLOTS, ...ENCODER_SLOTS].map(slot => [slot, String(deviceConfig.combos?.[host]?.[slot] ?? "NONE")]))
  ]));
  return next;
}

function titleForSlot(slot) {
  return SLOT_TITLES[slot] || `Button ${slot}`;
}

function isConfigured(slot) {
  return Boolean(config?.profiles?.[config.host]?.[slot] && config.profiles[config.host][slot] !== "NONE");
}

function applyTheme() {
  document.documentElement.dataset.theme = config?.preferences?.theme || "dark";
  document.documentElement.style.setProperty("--key-gap", `${config?.preferences?.gridGap || 12}px`);
}

function persistSoon() {
  if (!configLoaded || !config) return;
  clearTimeout(persistTimer);
  persistTimer = setTimeout(() => {
    persistNow().catch(error => toast(`Could not save local settings: ${formatError(error)}`, true));
  }, 240);
}

async function persistNow() {
  clearTimeout(persistTimer);
  persistTimer = null;
  if (!configLoaded || !config) return;
  config = await window.macropad.saveAppConfig(config);
}

function markDevicePending() {
  config.deviceWritePending = true;
  persistSoon();
  renderSyncSummary();
}

function slotPosition(slot, layout = config.layout) {
  return layout.positions[slot];
}

function createKeyButton(slot, { layout = config.layout, compact = false, draggable = false, selected = false } = {}) {
  const position = slotPosition(slot, layout);
  const button = document.createElement("button");
  button.type = "button";
  button.className = `key-button${selected ? " selected" : ""}${slot === selectedLayoutSlot && layoutEditing ? " layout-selected" : ""}`;
  button.dataset.slot = slot;
  button.dataset.tooltip = `SW${slot} — Select physical slot ${slot} to edit its label and shortcut. Visual position does not change its firmware mapping.`;
  button.setAttribute("aria-label", `Physical slot ${slot}, ${config.labels[slot] || "Unlabeled"}, ${config.profiles[config.host][slot] || "NONE"}`);
  button.draggable = draggable;
  if (position) {
    button.style.gridRow = `${position.row + 1} / span ${position.rowSpan}`;
    button.style.gridColumn = `${position.column + 1} / span ${position.columnSpan}`;
  }

  const physical = document.createElement("span");
  physical.className = "key-slot";
  physical.textContent = `SW${slot}`;
  const label = document.createElement("span");
  label.className = "key-label";
  label.textContent = config.labels[slot] || "Unassigned";
  const shortcut = document.createElement("span");
  shortcut.className = "key-shortcut";
  shortcut.textContent = slot === "9" && config.screenDesign.pages.length > 1 ? "Next OLED Page" : (config.profiles[config.host][slot] || "NONE");
  button.append(physical, label, shortcut);
  if (compact) button.classList.add("compact-key");
  return button;
}

function renderBoard(container, options = {}) {
  container.replaceChildren();
  container.style.setProperty("--key-gap", `${config.preferences.gridGap}px`);
  for (const slot of BUTTON_SLOTS) {
    const button = createKeyButton(slot, { ...options, selected: slot === selectedSlot && options.editor });
    button.addEventListener("click", () => {
      if (options.layout) {
        selectedLayoutSlot = slot;
        if (layoutEditing) renderLayoutBoard();
        else {
          selectedSlot = slot;
          showPage("buttons");
        }
        return;
      }
      selectedSlot = slot;
      renderButtonEditor();
      showPage("buttons");
    });
    if (options.draggable) {
      button.addEventListener("dragstart", event => {
        event.dataTransfer.setData("text/plain", slot);
        event.dataTransfer.effectAllowed = "move";
        button.classList.add("dragging");
      });
      button.addEventListener("dragend", () => button.classList.remove("dragging", "drop-target"));
      button.addEventListener("dragover", event => {
        event.preventDefault();
        button.classList.add("drop-target");
      });
      button.addEventListener("dragleave", () => button.classList.remove("drop-target"));
      button.addEventListener("drop", event => {
        event.preventDefault();
        button.classList.remove("drop-target");
        const source = event.dataTransfer.getData("text/plain");
        if (!source || source === slot) return;
        try {
          layoutDraft = swapLayoutSlots(layoutDraft, source, slot);
          selectedLayoutSlot = source;
          renderLayoutBoard();
          updateLayoutInspector();
        } catch (error) {
          toast(formatError(error), true);
        }
      });
    }
    container.appendChild(button);
  }
}

function renderEncoderSummary() {
  const container = $("dashboardEncoder");
  container.replaceChildren();
  for (const slot of ENCODER_SLOTS) {
    const row = document.createElement("div");
    row.className = "encoder-summary-item";
    const label = document.createElement("span");
    label.textContent = SLOT_TITLES[slot];
    const action = document.createElement("kbd");
    action.textContent = config.profiles[config.host][slot] || "NONE";
    row.append(label, action);
    container.appendChild(row);
  }
}

function renderDashboard() {
  if (!config) return;
  $("dashboardHost").textContent = HOST_LABELS[config.host];
  $("configuredCount").textContent = String([...BUTTON_SLOTS, ...ENCODER_SLOTS].filter(isConfigured).length);
  $("dashboardStatus").textContent = connection.connected ? "Connected" : "Disconnected";
  $("dashboardPort").textContent = connection.path || (connection.connected ? "Checking serial device" : "No active serial port");
  $("lastSync").textContent = lastSyncAt ? new Date(lastSyncAt).toLocaleTimeString() : "Not yet";
  $("syncDetail").textContent = config.deviceWritePending ? "Local changes are waiting to be written" : "Visual layout stays local to this app";
  renderBoard($("dashboardBoard"), { compact: true });
  renderEncoderSummary();
}

function renderButtonEditor() {
  $("hostSelect").value = config.host;
  $("buttonHostChip").textContent = HOST_LABELS[config.host];
  $("shortcutHostLabel").textContent = HOST_LABELS[config.host];
  renderBoard($("buttonEditorBoard"), { editor: true });
  const slot = selectedSlot;
  $("selectedSlotBadge").textContent = `SW${slot}`;
  $("selectedSlotTitle").textContent = titleForSlot(slot);
  $("selectedPosition").textContent = `Position ${config.layout.positions[slot].row * 3 + config.layout.positions[slot].column + 1}`;
  const pageNavigation = slot === "9" && config.screenDesign.pages.length > 1;
  $("selectedPosition").textContent = `Physical Slot ${slot}`;
  $("buttonLabel").value = config.labels[slot];
  $("buttonShortcut").value = pageNavigation ? "NEXT OLED PAGE" : config.profiles[config.host][slot];
  $("shortcutPreview").textContent = pageNavigation ? "NEXT OLED PAGE" : (config.profiles[config.host][slot] || "NONE");
  $("buttonLabel").disabled = pageNavigation;
  $("buttonLabel").hidden = pageNavigation;
  $("buttonLabel").previousElementSibling.hidden = pageNavigation;
  $("buttonShortcut").disabled = pageNavigation;
  $("clearShortcutButton").disabled = pageNavigation;
  $("restoreButtonDefault").disabled = pageNavigation;
  $("clearShortcutButton").hidden = pageNavigation;
  $("restoreButtonDefault").hidden = pageNavigation;
  $("normalButtonAssignment").hidden = pageNavigation;
  $("sw9NextPageAction").hidden = !pageNavigation;
  $("buttonEditorBoard").setAttribute("aria-description", pageNavigation ? "SW9 is physical slot 9. Multiple OLED pages are enabled, so SW9 switches to the next page and wraps to page 1." : "Physical 3 by 3 button slots.");
  const subtitle = document.querySelector("#view-buttons .inspector-header p");
  if (subtitle) subtitle.textContent = pageNavigation ? "Physical Slot 9 · Next OLED Page" : "Physical slot · Visual position is shown separately";
  $("sw9ActionDescription").hidden = slot !== "9" || pageNavigation;
  $("sw9ActionDescription").textContent = "SW9 · Physical Slot 9 · Action: Normal Button Assignment. This assignment remains saved when the OLED has one page.";
}

function makeEncoderEditorCard(slot) {
  const card = document.createElement("article");
  card.className = "panel encoder-card";
  const icon = document.createElement("div");
  icon.className = "encoder-card-icon";
  icon.textContent = slot === "CW" ? "↻" : slot === "CCW" ? "↺" : "●";
  const title = document.createElement("h3");
  title.textContent = SLOT_TITLES[slot];
  const description = document.createElement("p");
  description.textContent = `Firmware action · ${slot}`;
  const label = document.createElement("label");
  label.className = "field-label";
  label.htmlFor = `encoder-label-${slot}`;
  label.textContent = "Action label";
  const labelInput = document.createElement("input");
  labelInput.id = `encoder-label-${slot}`;
  labelInput.className = "text-input";
  labelInput.maxLength = 8;
  labelInput.value = config.labels[slot];
  labelInput.placeholder = "e.g. Volume";
  labelInput.addEventListener("input", () => {
    config.labels[slot] = labelInput.value.slice(0, 8);
    markDevicePending();
    renderDashboard();
  });
  const shortcutLabel = document.createElement("label");
  shortcutLabel.className = "field-label";
  shortcutLabel.htmlFor = `encoder-shortcut-${slot}`;
  shortcutLabel.textContent = "Shortcut";
  const shortcutInput = document.createElement("input");
  shortcutInput.id = `encoder-shortcut-${slot}`;
  shortcutInput.className = "text-input mono-input";
  shortcutInput.maxLength = 64;
  shortcutInput.value = config.profiles[config.host][slot];
  shortcutInput.placeholder = "e.g. VOL_UP";
  shortcutInput.addEventListener("input", () => {
    config.profiles[config.host][slot] = shortcutInput.value.trim().toUpperCase() || "NONE";
    markDevicePending();
    renderDashboard();
  });
  const preview = document.createElement("div");
  preview.className = "shortcut-preview";
  const current = document.createElement("span");
  current.className = "preview-label";
  current.textContent = "CURRENT ACTION";
  const key = document.createElement("kbd");
  key.textContent = config.profiles[config.host][slot] || "NONE";
  preview.append(current, key);
  shortcutInput.addEventListener("input", () => { key.textContent = config.profiles[config.host][slot]; });
  const actions = document.createElement("div");
  actions.className = "inspector-actions";
  const clear = document.createElement("button");
  clear.className = "button secondary";
  clear.textContent = "Clear assignment";
  clear.addEventListener("click", () => {
    config.profiles[config.host][slot] = "NONE";
    shortcutInput.value = "NONE";
    key.textContent = "NONE";
    markDevicePending();
  });
  const restore = document.createElement("button");
  restore.className = "text-button";
  restore.textContent = "Restore slot defaults";
  restore.addEventListener("click", () => {
    config.labels[slot] = "";
    config.profiles[config.host][slot] = DEFAULT_ACTIONS[slot];
    labelInput.value = "";
    shortcutInput.value = "NONE";
    key.textContent = "NONE";
    markDevicePending();
  });
  actions.append(clear, restore);
  card.append(icon, title, description, label, labelInput, shortcutLabel, shortcutInput, preview, actions);
  return card;
}

function renderEncoderEditor() {
  $("encoderHostChip").textContent = HOST_LABELS[config.host];
  const container = $("encoderEditor");
  container.replaceChildren(...ENCODER_SLOTS.map(makeEncoderEditorCard));
}

function updateLayoutInspector() {
  const position = (layoutEditing ? layoutDraft : config.layout).positions[selectedLayoutSlot];
  $("layoutSelection").textContent = `SW${selectedLayoutSlot} · visual row ${position.row + 1}, column ${position.column + 1}`;
  $("layoutWidth").value = String(position.columnSpan);
  $("layoutHeight").value = String(position.rowSpan);
  $("layoutWidth").disabled = !layoutEditing;
  $("layoutHeight").disabled = !layoutEditing;
}

function renderLayoutBoard() {
  const board = $("layoutBoard");
  board.classList.toggle("editing", layoutEditing);
  const layout = layoutEditing ? layoutDraft : config.layout;
  renderBoard(board, { layout, draggable: layoutEditing });
  for (const button of board.querySelectorAll(".key-button")) {
    button.classList.toggle("layout-selected", button.dataset.slot === selectedLayoutSlot);
  }
  updateLayoutInspector();
}

function screenDisplayText(element) {
  if (element.binding === "HOST") return HOST_LABELS[config.host] || "Windows";
  if (element.binding === "LAST") return "Browser";
  if (element.binding === "ENCODER") return "Vol +";
  if (element.binding === "HID") return "";
  return element.text;
}

function drawScreenPreview() {
  const canvas = $("screenCanvas");
  if (!canvas || !config) return;
  const context = canvas.getContext("2d");
  context.imageSmoothingEnabled = false;
  context.fillStyle = "#05080c";
  context.fillRect(0, 0, 128, 64);
  screenElements().forEach((element, index) => {
    if (element.binding === "KEYGRID") {
      context.strokeStyle = "#e7edf5";
      for (let row = 0; row < 3; row++) for (let column = 0; column < 3; column++) {
        context.beginPath();
        context.roundRect(element.x + column * 22, element.y + row * 22, 18, 18, 3);
        context.stroke();
      }
      if (!screenPreviewMode && index === selectedScreenElement) {
        context.strokeStyle = "#38d4a0"; context.strokeRect(element.x - 1, element.y - 1, 64, 64);
      }
      return;
    }
    const value = screenDisplayText(element);
    if (!value) return;
    const width = value.length * 6 * element.size;
    let x = element.x;
    if (element.alignment === "CENTER") x -= Math.floor(width / 2);
    else if (element.alignment === "RIGHT") x -= width;
    const inverse = element.mode === "INVERSE";
    context.fillStyle = inverse ? "#f1f5f9" : "#05080c";
    context.fillRect(x, element.y, width, 8 * element.size);
    context.fillStyle = inverse ? "#05080c" : "#f1f5f9";
    const font = window.macropadOledFont;
    for (let n = 0; n < value.length; n++) {
      const code = value.charCodeAt(n);
      const glyph = Math.max(0, Math.min(94, code - 32)) * 5;
      for (let column = 0; column < 5; column++) {
        const bits = font[glyph + column];
        for (let row = 0; row < 7; row++) if (bits & (1 << row)) {
          context.fillRect(x + (n * 6 + column) * element.size, element.y + row * element.size, element.size, element.size);
        }
      }
    }
    if (!screenPreviewMode && index === selectedScreenElement) {
      context.strokeStyle = "#38d4a0";
      context.lineWidth = 1;
      context.strokeRect(x - 1, element.y - 1, Math.max(2, width + 2), 8 * element.size + 2);
    }
  });
}

function renderScreenInspector() {
  const element = screenElements()[selectedScreenElement];
  $("screenEmptyInspector").hidden = Boolean(element);
  $("screenInspectorFields").hidden = !element;
  $("screenUndoButton").disabled = screenHistoryIndex <= 0;
  $("screenRedoButton").disabled = screenHistoryIndex >= screenHistory.length - 1;
  $("screenDuplicateButton").disabled = !element || screenElements().length >= 8;
  $("screenUploadButton").disabled = !connection.connected;
  $("screenReadButton").disabled = !connection.connected;
  $("screenUploadButton").disabled = !connection.connected;
  $("screenSelectionLabel").textContent = element ? `Element ${selectedScreenElement + 1} · draggable on the preview` : "Select text in the preview";
  if (element) {
    $("screenText").value = element.text;
    $("screenText").disabled = element.binding !== "STATIC";
    $("screenX").value = element.x;
    $("screenY").value = element.y;
    $("screenBinding").value = element.binding;
    $("screenSize").value = String(element.size);
    $("screenMode").value = element.mode;
    $("screenAlignment").value = element.alignment;
  }
  for (const id of ["screenText", "screenX", "screenY", "screenBinding", "screenSize", "screenMode", "screenAlignment", "screenDeleteButton"]) $(id).disabled = !element || screenPreviewMode || (id === "screenText" && element.binding !== "STATIC");
  if (element?.binding === "KEYGRID") {
    $("screenSize").disabled = true;
    $("screenMode").disabled = true;
    $("screenAlignment").disabled = true;
  }
  drawScreenPreview();
}

function pushScreenHistory() {
  screenHistory = screenHistory.slice(0, screenHistoryIndex + 1);
  screenHistory.push(clone(config.screenDesign));
  if (screenHistory.length > 40) screenHistory.shift();
  screenHistoryIndex = screenHistory.length - 1;
}

function updateScreenElement(field, value) {
  const element = screenElements()[selectedScreenElement];
  if (!element) return;
  const next = clone(config.screenDesign);
  const item = next.pages[selectedScreenPage].elements[selectedScreenElement];
  item[field] = ["x", "y", "size"].includes(field) ? Number(value) : value;
  config.screenDesign = next;
  pushScreenHistory();
  renderScreenInspector();
}

function applyScreenDesign(design) {
  config.screenDesign = clone(design);
  selectedScreenPage = 0;
  renderScreenPages();
  selectedScreenElement = Math.max(0, screenElements().length - 1);
  screenHistory = [clone(config.screenDesign)];
  screenHistoryIndex = 0;
  renderScreenInspector();
}

async function saveScreenLocally() {
  try {
    config = await window.macropad.saveAppConfig({ ...config, screenDesign: config.screenDesign });
    $("screenDeviceStatus").textContent = "Saved locally · device unchanged";
    toast("Screen design saved locally. The ESP32 was not changed.");
  } catch (error) { toast(`Screen design is invalid: ${formatError(error)}`, true); }
}

async function uploadScreenDesign() {
  if (!connection.connected) { toast("Connect the Macropad before uploading a screen design.", true); return; }
  try {
    const result = await window.macropad.saveScreenDesign(config.screenDesign);
    if (result.cancelled) return;
    $("screenDeviceStatus").textContent = "Uploaded · verified on ESP32";
    toast("OLED design uploaded and read back from the ESP32.");
    log(`OLED screen layout uploaded and verified (${result.sent} commands).`);
  } catch (error) { $("screenDeviceStatus").textContent = "Upload failed · local copy kept"; toast(`Screen upload failed: ${formatError(error)}`, true); }
}

async function readScreenFromDevice() {
  try {
    const result = await window.macropad.getScreenDesign();
    if (!result.supported) {
      $("screenDeviceStatus").textContent = "Firmware uses its built-in screen";
      toast("This firmware has no saved custom screen design. The current firmware renderer remains active.");
      return;
    }
    const same = JSON.stringify(result.design.pages.map(page => page.elements.map(({ id, ...item }) => item))) === JSON.stringify(config.screenDesign.pages.map(page => page.elements.map(({ id, ...item }) => item)));
    $("screenDeviceStatus").textContent = same ? "Local and device designs match" : "Device has a different saved design";
    toast(same ? "The local design matches the ESP32." : "Read completed. The local design was preserved; device design differs.");
  } catch (error) { toast(`Could not read the OLED design: ${formatError(error)}`, true); }
}

async function startScreenImport() {
  try {
    const result = await window.macropad.previewScreenImport();
    if (result.cancelled) return;
    pendingScreenImport = result.design;
    $("screenImportSummary").textContent = `${result.fileName} · ${result.design.pages.length} OLED page(s)`;
    const preview = $("screenImportPreview");
    preview.replaceChildren(...result.design.pages.flatMap((page, pageIndex) => [
      Object.assign(document.createElement("strong"), { textContent: page.name || `Page ${pageIndex + 1}` }),
      ...page.elements.map(item => Object.assign(document.createElement("div"), { textContent: `${item.binding} · ${item.text || "(dynamic)"} · x ${item.x}, y ${item.y} · ${item.size}× · ${item.mode}` }))
    ]));
    $("screenImportDialog").showModal();
  } catch (error) { toast(`Screen import preview failed: ${formatError(error)}`, true); }
}

async function applyScreenImport() {
  if (!pendingScreenImport) return;
  applyScreenDesign(pendingScreenImport);
  pendingScreenImport = null;
  $("screenImportDialog").close();
  $("screenDeviceStatus").textContent = "Imported · local only";
  await saveScreenLocally();
}

async function refreshAiStatus() {
  try {
    const status = await window.macropad.getAiStatus();
    aiKeyConfigured = status.keyConfigured;
    const label = status.keyConfigured ? "OPENAI READY" : "AI NOT CONFIGURED";
    $("aiDesignerStatus").textContent = label;
    $("aiSettingsStatus").textContent = status.secureStorageAvailable
      ? (status.keyConfigured ? "OpenAI key encrypted and stored in the system credential service." : "No key stored. Screen editing and device upload work without AI.")
      : "System credential service unavailable. API keys will not be stored insecurely.";
    $("aiEnabledToggle").checked = config.preferences.aiEnabled;
    $("aiEnabledToggle").disabled = !status.secureStorageAvailable;
    const aiReady = status.secureStorageAvailable && status.keyConfigured && config.preferences.aiEnabled;
    $("screenAiGenerateButton").disabled = !aiReady;
    $("testAiConnectionButton").disabled = !status.secureStorageAvailable || !status.keyConfigured;
    $("clearAiKeyButton").disabled = !status.keyConfigured;
    $("openAiSettingsButton").hidden = aiReady;
    $("saveAiKeyButton").disabled = !status.secureStorageAvailable;
  } catch (error) { $("aiSettingsStatus").textContent = formatError(error); }
}

async function generateScreenWithAi() {
  if (!aiKeyConfigured || !config.preferences.aiEnabled) {
    $("screenAiResponse").textContent = "AI assistance is not configured. Go to Settings → AI Assistance and add your OpenAI API key.";
    $("openAiSettingsButton").hidden = false;
    return;
  }
  const prompt = $("screenAiPrompt").value.trim();
  if (!prompt) { toast("Describe the screen layout first.", true); return; }
  try {
    $("screenAiGenerateButton").disabled = true;
    $("screenAiResponse").textContent = "Generating and validating a screen layout…";
    const result = await window.macropad.generateScreenDesign({ prompt, currentDesign: config.screenDesign });
    pendingAiDesign = result.design;
    $("aiDesignCount").textContent = `AI generated ${result.design.pages.length} page(s).`;
    const aiPreview = $("aiDesignPreview");
    aiPreview.replaceChildren(...result.design.pages.flatMap((page, pageIndex) => [
      Object.assign(document.createElement("strong"), { textContent: page.name || `Page ${pageIndex + 1}` }),
      ...page.elements.map(element => Object.assign(document.createElement("div"), { textContent: `${element.binding} · ${element.text || "(dynamic)"} · (${element.x}, ${element.y})` }))
    ]));
    aiPreview.hidden = false;
    $("screenAiResponse").textContent = [result.explanation, ...result.notes].join("\n");
    $("aiDesignReview").hidden = false;
  } catch (error) { $("screenAiResponse").textContent = formatError(error); toast(`AI design failed: ${formatError(error)}`, true); }
  finally { $("screenAiGenerateButton").disabled = false; }
}

function renderSettings() {
  $("themeSelect").value = config.preferences.theme;
  $("gridGapSelect").value = String(config.preferences.gridGap);
  $("aiEnabledToggle").checked = config.preferences.aiEnabled;
  renderDeviceInfo();
}

function renderDeviceInfo() {
  const list = $("deviceInfoList");
  list.replaceChildren();
  const ports = Array.isArray(connectionInfo.ports) ? connectionInfo.ports : [];
  const active = connectionInfo.connected ? connectionInfo : null;
  const selected = active || ports.find(port => port.manufacturer || port.vendorId) || null;
  const fields = [
    ["Status", connection.connected ? "Connected" : "Disconnected"],
    ["Serial path", selected?.path || "Not connected"],
    ["Manufacturer", selected?.manufacturer || "—"],
    ["USB vendor", selected?.vendorId || "—"],
    ["USB product", selected?.productId || "—"],
    ["Serial number", selected?.serialNumber || "—"],
    ["Available ports", String(ports.length)]
  ];
  for (const [term, value] of fields) {
    const dt = document.createElement("dt");
    const dd = document.createElement("dd");
    dt.textContent = term;
    dd.textContent = value;
    list.append(dt, dd);
  }
}

function renderSyncSummary() {
  const connected = Boolean(connection.connected);
  const state = syncState.state;
  const syncing = state === "reading" || state === "saving";
  const failed = state === "failed";
  const synchronized = state === "synchronized" && !config?.deviceWritePending;
  const message = failed ? "Synchronization failed" : syncing ? (state === "reading" ? "Reading configuration" : "Saving configuration") : synchronized ? "Synchronized" : connected ? "Connected" : "Disconnected";
  $("sideConnection").textContent = message;
  $("sidePort").textContent = connection.path || (connected ? "Checking serial device" : "No serial port");
  $("dashboardStatus").textContent = connected ? "Connected" : "Disconnected";
  $("dashboardPort").textContent = connection.path || (connected ? "Checking serial device" : "No active serial port");
  $("syncLabel").textContent = config?.deviceWritePending && connected ? "Changes waiting to sync" : message;
  $("syncIndicator").className = `sync-indicator${syncing ? " syncing" : synchronized ? " synced" : failed ? " failed" : ""}`;
  $("connectionDot").className = `connection-dot${connected ? " connected" : " disconnected"}`;
  $("syncPillDot").className = connected ? "connected" : "disconnected";
  $("syncPillText").textContent = config?.deviceWritePending && connected ? "Local changes pending" : message;
  $("connectButton").disabled = syncing;
  $("disconnectButton").disabled = !connected || syncing;
  $("reloadDeviceButton").disabled = !connected || syncing;
  $("resetDeviceButton").disabled = !connected || syncing;
  $("saveDeviceButton").disabled = !connected || syncing || !config;
  $("saveDeviceButton").textContent = config?.deviceWritePending ? "Save changes to device" : "Save to device";
  if (syncState.detail && failed) $("syncDetail").textContent = syncState.detail;
}

function renderAll() {
  if (!config) return;
  applyTheme();
  $("hostSelect").value = config.host;
  renderDashboard();
  renderButtonEditor();
  renderEncoderEditor();
  renderLayoutBoard();
  renderScreenPages();
  if (screenHistoryIndex < 0) {
    screenHistory = [clone(config.screenDesign)];
    screenHistoryIndex = 0;
  }
  renderScreenInspector();
  renderSettings();
  renderSyncSummary();
}

function showPage(name) {
  if (!PAGE_LABELS[name]) return;
  document.querySelectorAll(".view").forEach(section => section.classList.toggle("active-view", section.id === `view-${name}`));
  document.querySelectorAll(".nav-item").forEach(button => button.classList.toggle("active", button.dataset.view === name));
  $("pageEyebrow").textContent = PAGE_LABELS[name][0];
  $("pageTitle").textContent = PAGE_LABELS[name][1];
  if (config && config.preferences.startView !== name) {
    config.preferences.startView = name;
    persistSoon();
  }
}

async function refreshDeviceInfo() {
  try {
    connectionInfo = await window.macropad.getDeviceInfo();
    renderDeviceInfo();
  } catch (error) {
    toast(`Could not read device details: ${formatError(error)}`, true);
  }
}

async function syncFromDevice({ discardLocalChanges = false } = {}) {
  if (!connection.connected || !config) return;
  if (config.deviceWritePending && !discardLocalChanges) {
    toast("Local changes are waiting to be saved. Save them or explicitly reload from the device.");
    return;
  }
  if (config.deviceWritePending && discardLocalChanges && !window.confirm("Discard local macro edits and replace them with the current ESP32 settings?")) return;
  try {
    const deviceConfig = await window.macropad.getConfig();
    config = mergeDeviceConfig(deviceConfig, config);
    config.deviceWritePending = false;
    config = await window.macropad.saveAppConfig(config);
    lastSyncAt = new Date().toISOString();
    log(`Loaded ${HOST_LABELS[deviceConfig.host] || deviceConfig.host} settings from ${connection.path || "the Macropad"}.`);
    renderAll();
  } catch (error) {
    syncState = { state: "failed", detail: formatError(error) };
    log(`GET failed: ${formatError(error)}`);
    renderSyncSummary();
    toast(`Could not read Macropad settings: ${formatError(error)}`, true);
  }
}

async function handleDiscovery(found) {
  queuedDiscovery = found;
  if (!found) {
    connection = { connected: false };
    renderSyncSummary();
    log("No compatible Macropad responded to HELLO.");
    await refreshDeviceInfo();
    return;
  }
  connection = { connected: true, path: found.path, info: found.info };
  connectionInfo = { ...found.info, connected: true, path: found.path, ports: connectionInfo.ports || [] };
  log(`HELLO succeeded on ${found.path}: ${found.response}.`);
  renderSyncSummary();
  await refreshDeviceInfo();
  if (!configLoaded) return;
  if (config.deviceWritePending) {
    toast("Device connected. Local macro changes are preserved; choose Save to device or Reload from device.");
    return;
  }
  await syncFromDevice();
}

async function saveToDevice() {
  if (!connection.connected || !config) return;
  try {
    await persistNow();
    const result = await window.macropad.saveDeviceConfig(config);
    if (result.cancelled) return;
    config = result.appConfig;
    config.deviceWritePending = false;
    lastSyncAt = new Date().toISOString();
    log(`Saved ${result.sent} protocol commands and read the configuration back from the ESP32.`);
    renderAll();
    toast("Settings saved and verified with GET.");
  } catch (error) {
    syncState = { state: "failed", detail: formatError(error) };
    renderSyncSummary();
    log(`Save failed: ${formatError(error)}`);
    toast(`Could not save to Macropad: ${formatError(error)}`, true);
  }
}

async function resetDevice() {
  try {
    const result = await window.macropad.resetDevice();
    if (result.cancelled) return;
    config = result.appConfig;
    config.deviceWritePending = false;
    lastSyncAt = new Date().toISOString();
    renderAll();
    log("Device reset completed; defaults were read back from the ESP32.");
    toast("Device shortcuts reset. Application theme and layout were kept.");
  } catch (error) {
    syncState = { state: "failed", detail: formatError(error) };
    renderSyncSummary();
    log(`Device reset failed: ${formatError(error)}`);
    toast(`Could not reset device: ${formatError(error)}`, true);
  }
}

function changeHost(host) {
  if (!HOSTS.includes(host) || host === config.host) return;
  config.host = host;
  markDevicePending();
  renderAll();
  toast(`${HOST_LABELS[host]} selected. Save to device to update the ESP32 host profile.`);
}

function setSelectedLabel(value) {
  config.labels[selectedSlot] = value.slice(0, 8);
  markDevicePending();
  renderBoard($("dashboardBoard"), { compact: true });
  renderBoard($("buttonEditorBoard"), { editor: true });
  $("selectedPosition").textContent = `Position ${config.layout.positions[selectedSlot].row * 3 + config.layout.positions[selectedSlot].column + 1}`;
  renderDashboard();
}

function setSelectedShortcut(value) {
  const shortcut = value.trim().toUpperCase() || "NONE";
  config.profiles[config.host][selectedSlot] = shortcut;
  $("shortcutPreview").textContent = shortcut;
  markDevicePending();
  renderBoard($("dashboardBoard"), { compact: true });
  renderBoard($("buttonEditorBoard"), { editor: true });
  renderDashboard();
}

function beginLayoutEdit() {
  layoutDraft = clone(config.layout);
  layoutEditing = true;
  $("layoutModeTitle").textContent = "Unsaved layout changes";
  $("layoutModeHint").textContent = "Drag keys to swap visual positions. Physical firmware slots stay fixed.";
  $("editLayoutButton").hidden = true;
  $("cancelLayoutButton").hidden = false;
  $("resetLayoutButton").hidden = false;
  $("saveLayoutButton").hidden = false;
  renderLayoutBoard();
}

function endLayoutEdit() {
  layoutEditing = false;
  layoutDraft = null;
  $("layoutModeTitle").textContent = "Layout saved";
  $("layoutModeHint").textContent = "Enter edit mode to rearrange keys or change their visual size.";
  $("editLayoutButton").hidden = false;
  $("cancelLayoutButton").hidden = true;
  $("resetLayoutButton").hidden = true;
  $("saveLayoutButton").hidden = true;
  renderLayoutBoard();
}

function changeLayoutSize() {
  if (!layoutEditing) return;
  try {
    layoutDraft = resizeLayoutSlot(
      layoutDraft,
      selectedLayoutSlot,
      Number($("layoutHeight").value),
      Number($("layoutWidth").value)
    );
    renderLayoutBoard();
  } catch (error) {
    toast(formatError(error), true);
    updateLayoutInspector();
  }
}

async function saveLayout() {
  if (!layoutEditing || !layoutDraft) return;
  try {
    config.layout = validateLayout(layoutDraft);
    config = await window.macropad.saveAppConfig(config);
    endLayoutEdit();
    renderDashboard();
    renderButtonEditor();
    toast("Visual layout saved locally. The ESP32 was not changed.");
  } catch (error) {
    toast(`Layout could not be saved: ${formatError(error)}`, true);
  }
}

function appendSummaryCell(container, label, value) {
  const cell = document.createElement("div");
  cell.className = "summary-cell";
  const name = document.createElement("span");
  name.textContent = label;
  const content = document.createElement("strong");
  content.textContent = value;
  cell.append(name, content);
  container.appendChild(cell);
}

async function startImportPreview() {
  try {
    const result = await window.macropad.previewImport();
    if (result.cancelled) return;
    importPreview = result;
    $("importFileName").textContent = result.fileName;
    const summary = $("importSummary");
    summary.replaceChildren();
    appendSummaryCell(summary, "Current profile", HOST_LABELS[result.preview.host]);
    appendSummaryCell(summary, "Host profiles", result.preview.profiles.map(host => HOST_LABELS[host]).join(", "));
    appendSummaryCell(summary, "Labeled actions", String(result.preview.labeledSlots));
    appendSummaryCell(summary, "Visual key positions", String(result.preview.layoutSlots));
    appendSummaryCell(summary, "Theme", result.preview.theme);
    $("importPreviewDialog").showModal();
  } catch (error) {
    toast(`Import preview failed: ${formatError(error)}`, true);
  }
}

async function applyImport() {
  if (!importPreview) return;
  try {
    config = await window.macropad.applyImport(importPreview.config);
    config.deviceWritePending = true;
    await persistNow();
    $("importPreviewDialog").close();
    importPreview = null;
    renderAll();
    toast("Settings imported to this app only. Review them, then choose Save to device to write to the ESP32.");
    log("Imported a validated settings file into local application configuration.");
  } catch (error) {
    toast(`Could not apply settings: ${formatError(error)}`, true);
  }
}

async function exportSettings() {
  try {
    await persistNow();
    const result = await window.macropad.exportSettings();
    if (!result.cancelled) toast(`Settings exported to ${result.fileName}.`);
  } catch (error) {
    toast(`Export failed: ${formatError(error)}`, true);
  }
}

async function restoreUiDefaults() {
  if (!window.confirm("Restore the application theme, startup page, grid spacing, and visual layout? ESP32 shortcuts will not be reset.")) return;
  try {
    config = await window.macropad.restoreUiDefaults();
    layoutEditing = false;
    layoutDraft = null;
    renderAll();
    showPage("dashboard");
    toast("Application appearance and layout defaults restored. The ESP32 was not changed.");
  } catch (error) {
    toast(`Could not restore UI defaults: ${formatError(error)}`, true);
  }
}

function bindEvents() {
  initializeTooltips();
  document.querySelectorAll(".nav-item").forEach(button => button.addEventListener("click", () => showPage(button.dataset.view)));
  document.querySelectorAll("[data-go-view]").forEach(button => button.addEventListener("click", () => showPage(button.dataset.goView)));
  $("hostSelect").addEventListener("change", () => changeHost($("hostSelect").value));
  $("connectButton").addEventListener("click", async () => {
    try {
      $("connectButton").disabled = true;
      await window.macropad.discover();
    } catch (error) {
      syncState = { state: "failed", detail: formatError(error) };
      renderSyncSummary();
      toast(`Device discovery failed: ${formatError(error)}`, true);
    } finally {
      renderSyncSummary();
    }
  });
  $("disconnectButton").addEventListener("click", async () => {
    try { await window.macropad.disconnect(); }
    catch (error) { toast(`Disconnect failed: ${formatError(error)}`, true); }
  });
  $("reloadDeviceButton").addEventListener("click", () => syncFromDevice({ discardLocalChanges: true }));
  $("saveDeviceButton").addEventListener("click", saveToDevice);
  $("resetDeviceButton").addEventListener("click", resetDevice);
  $("buttonLabel").addEventListener("input", event => setSelectedLabel(event.target.value));
  $("buttonShortcut").addEventListener("input", event => setSelectedShortcut(event.target.value));
  $("clearShortcutButton").addEventListener("click", () => {
    config.profiles[config.host][selectedSlot] = "NONE";
    $("buttonShortcut").value = "NONE";
    $("shortcutPreview").textContent = "NONE";
    markDevicePending();
    renderAll();
  });
  $("restoreButtonDefault").addEventListener("click", () => {
    config.labels[selectedSlot] = "";
    config.profiles[config.host][selectedSlot] = DEFAULT_ACTIONS[selectedSlot];
    markDevicePending();
    renderAll();
  });
  $("layoutBoard").addEventListener("dragover", event => { if (layoutEditing) event.preventDefault(); });
  $("layoutWidth").addEventListener("change", changeLayoutSize);
  $("layoutHeight").addEventListener("change", changeLayoutSize);
  $("editLayoutButton").addEventListener("click", beginLayoutEdit);
  $("cancelLayoutButton").addEventListener("click", endLayoutEdit);
  $("resetLayoutButton").addEventListener("click", () => {
    if (!layoutEditing) return;
    layoutDraft = createDefaultLayout();
    selectedLayoutSlot = "1";
    renderLayoutBoard();
    toast("Default visual arrangement loaded. Save layout to keep it locally.");
  });
  $("saveLayoutButton").addEventListener("click", saveLayout);
  $("themeSelect").addEventListener("change", async () => {
    config.preferences.theme = $("themeSelect").value;
    applyTheme();
    await persistNow();
  });
  $("gridGapSelect").addEventListener("change", async () => {
    config.preferences.gridGap = Number($("gridGapSelect").value);
    applyTheme();
    renderDashboard(); renderButtonEditor(); renderLayoutBoard();
    await persistNow();
  });
  $("exportButton").addEventListener("click", exportSettings);
  $("importButton").addEventListener("click", startImportPreview);
  $("applyImportButton").addEventListener("click", applyImport);
  $("restoreUiButton").addEventListener("click", restoreUiDefaults);
  $("screenPageSelect").addEventListener("change", event => selectScreenPageIndex(Number(event.target.value)));
  $("screenPrevPageButton").addEventListener("click", () => selectScreenPageIndex(selectedScreenPage - 1));
  $("screenNextPageButton").addEventListener("click", () => selectScreenPageIndex(selectedScreenPage + 1));
  $("screenAddPageButton").addEventListener("click", () => addScreenPage());
  $("screenDuplicatePageButton").addEventListener("click", () => addScreenPage({ duplicate: true }));
  $("screenDeletePageButton").addEventListener("click", () => {
    if (config.screenDesign.pages.length <= 1) { toast("The final OLED page cannot be deleted.", true); return; }
    const returningToSingle = config.screenDesign.pages.length === 2;
    if (returningToSingle && !window.confirm("Delete this page and return to a single OLED page? Physical SW9 will resume its normal macro assignment after you upload.")) return;
    if (!returningToSingle && !window.confirm(`Delete ${config.screenDesign.pages[selectedScreenPage].name || `Page ${selectedScreenPage + 1}`}?`)) return;
    config.screenDesign.pages.splice(selectedScreenPage, 1);
    selectedScreenPage = Math.max(0, Math.min(selectedScreenPage, config.screenDesign.pages.length - 1));
    selectedScreenElement = 0;
    pushScreenHistory();
    renderScreenPages();
    renderScreenInspector();
    renderButtonEditor();
    renderDashboard();
  });
  $("screenShowPageButton").addEventListener("click", async () => {
    if (!connection.connected) return;
    try { await window.macropad.selectScreenPage(selectedScreenPage); toast(`Selected OLED Page ${selectedScreenPage + 1} on the ESP32.`); }
    catch (error) { toast(formatError(error), true); }
  });
  $("screenAddButton").addEventListener("click", () => {
    if (screenElements().length >= 8) { toast("Firmware supports at most eight text elements.", true); return; }
    screenElements().push({ id: `text-${Date.now().toString(36)}`, x: 4, y: 4, size: 1, mode: "NORMAL", alignment: "LEFT", binding: "STATIC", text: "Text" });
    selectedScreenElement = screenElements().length - 1; pushScreenHistory(); renderScreenInspector();
  });
  $("screenDuplicateButton").addEventListener("click", () => {
    const selected = screenElements()[selectedScreenElement];
    if (!selected || screenElements().length >= 8) return;
    screenElements().push({ ...selected, id: `copy-${Date.now().toString(36)}`, x: Math.min(127, selected.x + 6), y: Math.min(63, selected.y + 8) });
    selectedScreenElement = screenElements().length - 1; pushScreenHistory(); renderScreenInspector();
  });
  $("screenDeleteButton").addEventListener("click", () => {
    if (!screenElements()[selectedScreenElement]) return;
    screenElements().splice(selectedScreenElement, 1);
    selectedScreenElement = Math.max(0, selectedScreenElement - 1); pushScreenHistory(); renderScreenInspector();
  });
  for (const [id, field] of [["screenText", "text"], ["screenX", "x"], ["screenY", "y"], ["screenBinding", "binding"], ["screenSize", "size"], ["screenMode", "mode"], ["screenAlignment", "alignment"]]) {
    $(id).addEventListener(id === "screenText" ? "input" : "change", event => updateScreenElement(field, event.target.value));
  }
  $("screenUndoButton").addEventListener("click", () => {
    if (screenHistoryIndex <= 0) return;
    screenHistoryIndex--; config.screenDesign = clone(screenHistory[screenHistoryIndex]);
    selectedScreenPage = Math.min(selectedScreenPage, config.screenDesign.pages.length - 1); renderScreenPages();
    selectedScreenElement = Math.max(0, Math.min(selectedScreenElement, screenElements().length - 1)); renderScreenInspector();
  });
  $("screenRedoButton").addEventListener("click", () => {
    if (screenHistoryIndex >= screenHistory.length - 1) return;
    screenHistoryIndex++; config.screenDesign = clone(screenHistory[screenHistoryIndex]);
    selectedScreenPage = Math.min(selectedScreenPage, config.screenDesign.pages.length - 1); renderScreenPages();
    selectedScreenElement = Math.max(0, Math.min(selectedScreenElement, screenElements().length - 1)); renderScreenInspector();
  });
  $("screenPreviewButton").addEventListener("click", event => {
    screenPreviewMode = !screenPreviewMode;
    event.currentTarget.textContent = screenPreviewMode ? "Edit mode" : "Preview mode"; renderScreenInspector();
  });
  $("screenCanvas").addEventListener("pointerdown", event => {
    if (screenPreviewMode) return;
    const canvas = event.currentTarget;
    const px = event.offsetX * 128 / canvas.clientWidth;
    const py = event.offsetY * 64 / canvas.clientHeight;
    let hit = -1;
    for (let i = screenElements().length - 1; i >= 0; i--) {
      const item = screenElements()[i];
      if (item.binding === "KEYGRID") {
        if (px >= item.x && px <= item.x + 62 && py >= item.y && py <= item.y + 62) { hit = i; break; }
        continue;
      }
      const text = screenDisplayText(item);
      const width = text.length * 6 * item.size;
      let x = item.x;
      if (item.alignment === "CENTER") x -= width / 2;
      else if (item.alignment === "RIGHT") x -= width;
      if (px >= x - 2 && px <= x + width + 2 && py >= item.y - 2 && py <= item.y + 8 * item.size + 2) { hit = i; break; }
    }
    if (hit < 0) return;
    selectedScreenElement = hit; screenDrag = true; canvas.setPointerCapture(event.pointerId); renderScreenInspector();
  });
  $("screenCanvas").addEventListener("pointermove", event => {
    if (!screenDrag) return;
    const item = screenElements()[selectedScreenElement];
    if (!item) return;
    item.x = Math.max(0, Math.min(127, Math.floor(event.offsetX * 128 / event.currentTarget.clientWidth)));
    item.y = Math.max(0, Math.min(63, Math.floor(event.offsetY * 64 / event.currentTarget.clientHeight)));
    $("screenX").value = item.x; $("screenY").value = item.y; drawScreenPreview();
  });
  $("screenCanvas").addEventListener("pointerup", () => { if (screenDrag) pushScreenHistory(); screenDrag = false; renderScreenInspector(); });
  $("screenCanvas").addEventListener("pointercancel", () => { screenDrag = false; renderScreenInspector(); });
  $("screenSaveButton").addEventListener("click", saveScreenLocally);
  $("screenUploadButton").addEventListener("click", uploadScreenDesign);
  $("screenReadButton").addEventListener("click", readScreenFromDevice);
  $("screenExportButton").addEventListener("click", async () => {
    try {
      config = await window.macropad.saveAppConfig(config);
    const result = await window.macropad.exportScreenDesign(config.screenDesign);
      if (!result.cancelled) toast(`Screen design exported to ${result.fileName}.`);
    } catch (error) { toast(`Screen export failed: ${formatError(error)}`, true); }
  });
  $("screenImportButton").addEventListener("click", startScreenImport);
  $("screenApplyImportButton").addEventListener("click", applyScreenImport);
  $("screenImportDialog").addEventListener("close", () => { pendingScreenImport = null; });
  $("screenAiGenerateButton").addEventListener("click", generateScreenWithAi);
  $("applyAiDesignButton").addEventListener("click", () => {
    if (!pendingAiDesign) return;
    applyScreenDesign(pendingAiDesign); pendingAiDesign = null; $("aiDesignReview").hidden = true; $("aiDesignPreview").hidden = true;
    $("screenDeviceStatus").textContent = "AI design · local only";
    toast("AI design applied locally. It will not reach the ESP32 until you explicitly upload it.");
  });
  $("cancelAiDesignButton").addEventListener("click", () => { pendingAiDesign = null; $("aiDesignReview").hidden = true; $("aiDesignPreview").hidden = true; $("screenAiResponse").textContent = "Generated design discarded."; });
  $("openAiSettingsButton").addEventListener("click", () => showPage("settings"));
  $("toggleAiKeyButton").addEventListener("click", event => {
    const input = $("aiKeyInput"); const shown = input.type === "text";
    input.type = shown ? "password" : "text"; event.currentTarget.textContent = shown ? "Show" : "Hide";
  });
  $("aiEnabledToggle").addEventListener("change", async event => {
    try { await window.macropad.setAiEnabled(event.target.checked); config.preferences.aiEnabled = event.target.checked; await refreshAiStatus(); }
    catch (error) { event.target.checked = !event.target.checked; toast(formatError(error), true); }
  });
  $("testAiConnectionButton").addEventListener("click", async () => {
    $("aiSettingsStatus").textContent = "Testing OpenAI connection…";
    try { const result = await window.macropad.testAiConnection(); $("aiSettingsStatus").textContent = result.message; }
    catch (error) { $("aiSettingsStatus").textContent = formatError(error); }
  });
  $("saveAiKeyButton").addEventListener("click", async () => {
    try {
      const result = await window.macropad.setAiKey($("aiKeyInput").value);
      aiKeyConfigured = result.keyConfigured; $("aiKeyInput").value = "";
      await refreshAiStatus(); $("aiSettingsStatus").textContent = "API key saved securely.";
    } catch (error) { toast(`Could not store API key: ${formatError(error)}`, true); }
  });
  $("clearAiKeyButton").addEventListener("click", async () => {
    try { await window.macropad.clearAiKey(); await refreshAiStatus(); $("aiSettingsStatus").textContent = "Saved API key removed."; }
    catch (error) { toast(`Could not remove API key: ${formatError(error)}`, true); }
  });
  $("refreshDeviceInfoButton").addEventListener("click", refreshDeviceInfo);
  $("clearActivityButton").addEventListener("click", () => { $("activityLog").textContent = ""; });
  $("importPreviewDialog").addEventListener("close", () => { importPreview = null; });

  unsubscribeEvents.push(
    window.macropad.onConnection(data => {
      connection = data;
      renderSyncSummary();
      if (config) renderDashboard();
      renderDeviceInfo();
    }),
    window.macropad.onDiscovered(handleDiscovery),
    window.macropad.onSerialLine(line => log(`← ${line}`)),
    window.macropad.onError(error => {
      const message = typeof error === "string" ? error : `${error.path ? `${error.path}: ` : ""}${error.message || "Serial error"}`;
      log(`Serial error: ${message}`);
    }),
    window.macropad.onSyncState(data => {
      syncState = data;
      if (data.state === "synchronized") lastSyncAt = data.timestamp;
      renderSyncSummary();
      if (config) renderDashboard();
    }),
    window.macropad.onWarning(message => toast(message, true))
  );
  window.addEventListener("beforeunload", () => unsubscribeEvents.splice(0).forEach(unsubscribe => unsubscribe()));
}

async function initialize() {
  bindEvents();
  try {
    config = await window.macropad.getAppConfig();
    selectedScreenPage = 0;
    configLoaded = true;
    const version = await window.macropad.getVersion();
    $("appVersion").textContent = version;
    await refreshAiStatus();
    renderAll();
    showPage(config.preferences.startView);
    await refreshDeviceInfo();
    if (queuedDiscovery && !config.deviceWritePending) await syncFromDevice();
    if (config.deviceWritePending) toast("Local macro changes are preserved. Save them to the device or reload from the ESP32.");
  } catch (error) {
    toast(`Application settings could not be loaded: ${formatError(error)}`, true);
    log(`Startup error: ${formatError(error)}`);
  }
}

document.addEventListener("DOMContentLoaded", initialize, { once: true });
