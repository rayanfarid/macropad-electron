# Macropad Studio

Native Electron desktop editor for the ESP32-S3 3×3 Macropad.

Macropad Studio is built as a separate native installer for each desktop operating system. GitHub Actions runs the tests and builds Linux, Windows, and macOS installers; build artifacts are attached to each workflow run for download.

## Development

```sh
npm install
npm start
```

The app automatically searches Linux serial ports and uses the existing `HELLO`, `GET`, `HOST`, `LABEL`, `SET`, `SAVE`, and `RESET` protocol. It reads configuration after a successful handshake. Writes to the ESP32 require confirmation in a native dialog.

## OLED Screen Designer

The matching sketch is included at `firmware/keys_shorcuts.ino` (copied from the existing Macropad firmware source). Its existing display is a 128×64, 1-bit SSD1306 OLED rendered with Adafruit GFX. The Screen Designer supports up to eight independent OLED pages. Each page can use the live 3×3 key grid and up to seven additional text elements with the firmware's built-in 5×7 ASCII font at 1× or 2×, inverse monochrome, alignment, and the `HOST`, `LAST`, `ENCODER`, and `HID` live bindings. The hardware has no color, icon, custom-font, or host-system-metric support.

When more than one page is uploaded, physical firmware slot **SW9** becomes **Next OLED Page** on the ESP32 itself (wraps from the last page to page 1). Page switching continues to work with the PC disconnected. Existing SW9 macro assignments remain stored and resume when a one-page design is uploaded again. The eight-page limit matches the reserved NVS budget (~2056 bytes for the multi-page blob, asserted ≤2304 bytes in firmware).

The sketch expects the ESP32 Arduino core, Adafruit GFX, and Adafruit SSD1306 libraries. In Arduino IDE, open the sketch from the `firmware` directory, select the matching ESP32-S3 board, set **USB Mode** to **USB-OTG (TinyUSB)** and **USB CDC On Boot** to **Disabled**, then upload. This is a firmware update; it does not automatically run from the desktop app. The display wiring used by this sketch is SDA GPIO 4, SCL GPIO 5, and I²C address `0x3C` (some modules use `0x3D`).

Local screen designs are saved in app settings and imported/exported as versioned JSON. They do not change the device. Upload requires a native confirmation. Single-page uploads keep the legacy `SCREEN BEGIN/CLEAR/ITEM/VALIDATE/COMMIT/GET` path. Multi-page uploads use the compatible `SCREEN PAGES …` / `SCREEN PAGE …` extension and fail clearly if the connected firmware is too old. Screen data is stored under a separate ESP32 Preferences key (`scrn`); it does not issue macro `SAVE` or `RESET`. The legacy fixed screen remains active until a screen design is explicitly committed. The firmware source must be flashed to the ESP32 manually before screen upload features are available.

## Optional AI design assistant

The optional provider is the OpenAI Responses API. On Linux, Macropad Studio forces Chromium's `gnome-libsecret` password store so Electron `safeStorage` can use the desktop Secret Service (gnome-keyring on Omarchy/Hyprland). Linux's insecure `basic_text` fallback is rejected and never used silently. The key remains in the main process and renderer code cannot read it. A prompt and current design are sent to OpenAI only after the user selects Generate. Generated output is validated against the display schema before it enters the editor. Screen editing, saving, import/export, and firmware upload do not require an API key.

## Local settings

Visual layout, theme, spacing, selected startup page, and the editable macro model are stored in Electron's per-user settings directory. Visual layout changes never modify firmware slot IDs. Import previews a versioned JSON file and applies it to local app settings only; use **Save to device** separately to update the ESP32.

## Install

Download the installer for your operating system from the **Actions** tab of this repository.

- **Arch Linux / Omarchy / Manjaro:** `sudo pacman -U "Macropad Studio-1.0.0-x64.pacman"`
- **Debian / Ubuntu:** `sudo apt install "./Macropad Studio-1.0.0-amd64.deb"`
- **Fedora / RPM systems:** install the `.rpm` with your distribution's package manager.
- **Windows:** run the `Macropad Studio-1.0.0-x64-Setup.exe` installer.
- **macOS:** open the `.dmg` and move Macropad Studio to Applications.
- **Other Linux distributions:** use the AppImage. If FUSE 2 is unavailable, run it with `--appimage-extract-and-run`.

Linux package managers install desktop-menu entries and icons. The AppImage is portable and does not automatically add a menu entry.

Windows installers are currently unsigned, and macOS builds need Apple Developer ID signing and notarization for friction-free installation outside the Mac App Store.

No software license has been selected yet. Publishing this repository makes the source visible, but does not grant permission to redistribute or modify it.

## Development and tests

```sh
npm test
npm run check
npm run dist:appimage
npm run dist:deb
npm run dist:pacman
npm run dist:rpm
npm run dist:windows
npm run dist:mac
npm run dist
```

Installers are written to `dist/`. Linux package scripts create AppImage, Debian, RPM, and Arch packages. Windows NSIS installers are built on Windows (or Linux with Wine); macOS DMG and ZIP builds must be made on macOS.

Serial access follows the permissions assigned by Linux to `/dev/ttyACM*` and `/dev/ttyUSB*`. Add the account to the distribution's correct serial-access group if access is denied; the app does not change group membership.
