// 3x3 macropad - stage 2
// Editable shortcuts saved in flash + text command channel (COM and USB)
// Wiring: ROW -> switch -> diode anode, diode cathode -> COLUMN
// Arduino IDE: USB Mode = USB-OTG (TinyUSB), USB CDC On Boot = Disabled
// Upload through the COM port. Send commands from the Serial Monitor
// (115200, line ending = Newline) or from the desktop app over the USB port.

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "USB.h"
#include "USBCDC.h"
#include "USBHIDKeyboard.h"
#include "USBHIDConsumerControl.h"
#include <Preferences.h>
#include "screen-layout.h"

#if ARDUINO_USB_MODE
#error "Set Tools > USB Mode to: USB-OTG (TinyUSB)"
#endif

// ---------- Matrix ----------
const int colPins[3] = {38, 37, 36};
const int rowPins[3] = {13, 12, 11};

const uint8_t ROWS = 3;
const uint8_t COLS = 3;
const uint16_t DEBOUNCE_MS = 10;

bool keyState[ROWS][COLS];          // debounced state (true = pressed)
bool lastRaw[ROWS][COLS];           // last raw reading
uint32_t lastChange[ROWS][COLS];    // time of last raw change

// ---------- Rotary encoder ----------
const int ENC_CLK = 7;
const int ENC_DT  = 41;
const int ENC_SW  = 6;
const int8_t ENC_STEPS = 4;         // transitions per detent: use 2 if it counts double
const uint16_t LONG_PRESS_MS = 800; // hold the knob this long to change the OS

volatile int32_t encPos = 0;        // detent counter (changed in the ISR)
volatile uint8_t encState = 0;
volatile int8_t  encSub = 0;
int32_t lastPos = 0;

bool btnState = false;              // debounced encoder button (true = pressed)
bool btnLastRaw = false;
bool longFired = false;
uint32_t btnLastChange = 0;
uint32_t btnPressedAt = 0;

// Quadrature decoder: a state table ignores contact bounce
void IRAM_ATTR encoderISR() {
  static const int8_t table[16] = {0, -1, 1, 0,  1, 0, 0, -1,  -1, 0, 0, 1,  0, 1, -1, 0};
  encState = ((encState << 2) | (digitalRead(ENC_CLK) << 1) | digitalRead(ENC_DT)) & 0x0F;
  encSub += table[encState];

  if (encSub >= ENC_STEPS)       { encPos++; encSub = 0; }
  else if (encSub <= -ENC_STEPS) { encPos--; encSub = 0; }
}

// ---------- USB ----------
USBHIDKeyboard Keyboard;
USBHIDConsumerControl ConsumerControl;
USBCDC AppSerial;                   // command channel for the desktop app
bool hidEnabled = true;             // false = safe mode (knob held at power-up)

// ---------- Operating systems ----------
enum HostOs : uint8_t { HOST_WINDOWS, HOST_LINUX, HOST_MACOS, HOST_OMARCHY, HOST_COUNT };
const char* const HOST_NAMES[HOST_COUNT] = {"Windows", "Linux", "macOS", "Omarchy"};  // screen
const char* const HOST_IDS[HOST_COUNT]   = {"WINDOWS", "LINUX", "MACOS", "OMARCHY"};  // commands
const int HOST_ALL = 100;           // only used by the SET command

// ---------- Slots: 0..8 = SW1..SW9, then the three knob actions ----------
const uint8_t SLOT_COUNT = 12;
const uint8_t SLOT_CW    = 9;
const uint8_t SLOT_CCW   = 10;
const uint8_t SLOT_PRESS = 11;

const uint8_t KM_CTRL  = 0x01;
const uint8_t KM_SHIFT = 0x02;
const uint8_t KM_ALT   = 0x04;
const uint8_t KM_GUI   = 0x08;      // Windows key / Super / Command

const uint8_t TYPE_NONE  = 0;
const uint8_t TYPE_KEY   = 1;       // keyboard shortcut
const uint8_t TYPE_MEDIA = 2;       // media key (volume, play...)

// ---------- Saved configuration (stored in flash as text) ----------
const uint32_t CFG_MAGIC = 0x4D503032;   // "MP02"

struct Config {
  uint32_t magic;
  uint8_t  host;                              // current operating system
  char     labels[SLOT_COUNT][9];             // names shown on the screen (8 chars)
  char     combos[HOST_COUNT][SLOT_COUNT][24];  // e.g. "CTRL+SHIFT+M"
};

Config cfg;
Preferences prefs;
bool cfgDirty = false;
uint32_t cfgDirtyAt = 0;

// Parsed copy of the combos, rebuilt whenever they change (RAM only)
uint8_t  bType[HOST_COUNT][SLOT_COUNT];
uint8_t  bMods[HOST_COUNT][SLOT_COUNT];
uint16_t bCode[HOST_COUNT][SLOT_COUNT];

// ---------- Factory defaults ----------
const char* const DEFAULT_LABELS[SLOT_COUNT] = {
  "Copy", "Paste", "Cut", "Undo", "Redo", "Sel all", "Save", "Find", "Shot",
  "Vol +", "Vol -", "Mute"
};

const char* const DEFAULT_COMBOS[HOST_COUNT][SLOT_COUNT] = {
  // Windows
  { "CTRL+C", "CTRL+V", "CTRL+X", "CTRL+Z", "CTRL+Y", "CTRL+A", "CTRL+S", "CTRL+F",
    "GUI+SHIFT+S", "VOL_UP", "VOL_DOWN", "MUTE" },
  // Linux
  { "CTRL+C", "CTRL+V", "CTRL+X", "CTRL+Z", "CTRL+SHIFT+Z", "CTRL+A", "CTRL+S", "CTRL+F",
    "PRINTSCREEN", "VOL_UP", "VOL_DOWN", "MUTE" },
  // macOS
  { "GUI+C", "GUI+V", "GUI+X", "GUI+Z", "GUI+SHIFT+Z", "GUI+A", "GUI+S", "GUI+F",
    "GUI+SHIFT+4", "VOL_UP", "VOL_DOWN", "MUTE" },
  // Omarchy (Super+C/V/X is its universal clipboard)
  { "GUI+C", "GUI+V", "GUI+X", "CTRL+Z", "CTRL+SHIFT+Z", "CTRL+A", "CTRL+S", "CTRL+F",
    "PRINTSCREEN", "VOL_UP", "VOL_DOWN", "MUTE" },
};

// ---------- Names understood inside a combo ----------
struct NamedCode { const char* name; uint16_t code; };

const NamedCode NAMED_KEYS[] = {
  {"ENTER", KEY_RETURN}, {"ESC", KEY_ESC}, {"TAB", KEY_TAB}, {"SPACE", ' '},
  {"BACKSPACE", KEY_BACKSPACE}, {"DELETE", KEY_DELETE}, {"INSERT", KEY_INSERT},
  {"HOME", KEY_HOME}, {"END", KEY_END}, {"PAGEUP", KEY_PAGE_UP}, {"PAGEDOWN", KEY_PAGE_DOWN},
  {"UP", KEY_UP_ARROW}, {"DOWN", KEY_DOWN_ARROW}, {"LEFT", KEY_LEFT_ARROW},
  {"RIGHT", KEY_RIGHT_ARROW}, {"PRINTSCREEN", KEY_PRINT_SCREEN}, {"PLUS", '+'},
};

const NamedCode NAMED_MEDIA[] = {
  {"VOL_UP", 0xE9}, {"VOL_DOWN", 0xEA}, {"MUTE", 0xE2}, {"PLAY_PAUSE", 0xCD},
  {"NEXT", 0xB5}, {"PREV", 0xB6}, {"STOP", 0xB7},
};

// ---------- Text helpers ----------
void upperInPlace(char* s) {
  for (; *s; s++) {
    if (*s >= 'a' && *s <= 'z') *s -= 32;
  }
}

// Returns the next space-separated word and moves *p past it
char* nextToken(char** p) {
  char* s = *p;
  while (*s == ' ' || *s == '\t') s++;
  if (*s == 0) { *p = s; return nullptr; }
  char* start = s;
  while (*s && *s != ' ' && *s != '\t') s++;
  if (*s) { *s = 0; s++; }
  *p = s;
  return start;
}

uint8_t modifierBit(const char* t) {
  if (!strcmp(t, "CTRL") || !strcmp(t, "CONTROL")) return KM_CTRL;
  if (!strcmp(t, "SHIFT")) return KM_SHIFT;
  if (!strcmp(t, "ALT") || !strcmp(t, "OPTION")) return KM_ALT;
  if (!strcmp(t, "GUI") || !strcmp(t, "WIN") || !strcmp(t, "WINDOWS") || !strcmp(t, "SUPER") ||
      !strcmp(t, "CMD") || !strcmp(t, "COMMAND") || !strcmp(t, "META")) return KM_GUI;
  return 0;
}

int32_t mediaCode(const char* t) {
  for (uint8_t i = 0; i < sizeof(NAMED_MEDIA) / sizeof(NAMED_MEDIA[0]); i++) {
    if (!strcmp(t, NAMED_MEDIA[i].name)) return NAMED_MEDIA[i].code;
  }
  return -1;
}

int32_t keyCode(const char* t) {
  for (uint8_t i = 0; i < sizeof(NAMED_KEYS) / sizeof(NAMED_KEYS[0]); i++) {
    if (!strcmp(t, NAMED_KEYS[i].name)) return NAMED_KEYS[i].code;
  }
  if (t[0] == 'F' && t[1] >= '0' && t[1] <= '9') {          // F1 .. F12
    int n = atoi(t + 1);
    if (n >= 1 && n <= 12) return KEY_F1 + n - 1;
  }
  if (t[0] != 0 && t[1] == 0) {                              // a single character
    char c = t[0];
    if (c >= 'A' && c <= 'Z') c += 32;                       // letters are sent lowercase
    if (c >= 32 && c < 127) return (uint8_t)c;
  }
  return -1;
}

// Turns "CTRL+SHIFT+M", "F5", "VOL_UP" or "NONE" into type / modifiers / code
bool parseCombo(const char* text, uint8_t* type, uint8_t* mods, uint16_t* code) {
  char buf[24];
  strncpy(buf, text, 23);
  buf[23] = 0;
  upperInPlace(buf);

  if (!strcmp(buf, "NONE")) { *type = TYPE_NONE; *mods = 0; *code = 0; return true; }

  uint8_t m = 0;
  uint16_t key = 0;
  bool haveKey = false;
  bool media = false;
  char* save = nullptr;

  for (char* tok = strtok_r(buf, "+", &save); tok; tok = strtok_r(nullptr, "+", &save)) {
    uint8_t bit = modifierBit(tok);
    if (bit) { m |= bit; continue; }
    if (haveKey) return false;                 // only one main key allowed

    int32_t mc = mediaCode(tok);
    if (mc >= 0) { media = true; key = (uint16_t)mc; haveKey = true; continue; }

    int32_t k = keyCode(tok);
    if (k < 0) return false;
    key = (uint16_t)k;
    haveKey = true;
  }

  if (!haveKey) return false;
  if (media && m) return false;                // media keys take no modifiers
  *type = media ? TYPE_MEDIA : TYPE_KEY;
  *mods = m;
  *code = key;
  return true;
}

// ---------- Config storage ----------
void rebuildOne(uint8_t h, uint8_t slot) {
  if (!parseCombo(cfg.combos[h][slot], &bType[h][slot], &bMods[h][slot], &bCode[h][slot])) {
    bType[h][slot] = TYPE_NONE;
    bMods[h][slot] = 0;
    bCode[h][slot] = 0;
  }
}

void rebuildAll() {
  for (uint8_t h = 0; h < HOST_COUNT; h++) {
    for (uint8_t s = 0; s < SLOT_COUNT; s++) rebuildOne(h, s);
  }
}

void applyCombo(uint8_t h, uint8_t slot, const char* combo) {
  memset(cfg.combos[h][slot], 0, 24);
  strncpy(cfg.combos[h][slot], combo, 23);
  rebuildOne(h, slot);
}

void loadDefaults() {
  memset(&cfg, 0, sizeof(cfg));
  cfg.magic = CFG_MAGIC;
  cfg.host = prefs.getUChar("host", HOST_WINDOWS);   // keep the OS chosen in stage 1
  for (uint8_t s = 0; s < SLOT_COUNT; s++) {
    strncpy(cfg.labels[s], DEFAULT_LABELS[s], 8);
    for (uint8_t h = 0; h < HOST_COUNT; h++) {
      strncpy(cfg.combos[h][s], DEFAULT_COMBOS[h][s], 23);
    }
  }
}

void saveConfig() {
  prefs.putBytes("cfg", &cfg, sizeof(cfg));
  Serial.println("Config saved to flash");
}

void markDirty() {                  // saved automatically 2 seconds after the last change
  cfgDirty = true;
  cfgDirtyAt = millis();
}

void loadConfig() {
  if (prefs.getBytesLength("cfg") == sizeof(cfg)) {
    prefs.getBytes("cfg", &cfg, sizeof(cfg));
    if (cfg.magic != CFG_MAGIC) loadDefaults();
  } else {
    loadDefaults();
  }
  if (cfg.host >= HOST_COUNT) cfg.host = HOST_WINDOWS;
  for (uint8_t s = 0; s < SLOT_COUNT; s++) {         // make sure all text ends properly
    cfg.labels[s][8] = 0;
    for (uint8_t h = 0; h < HOST_COUNT; h++) cfg.combos[h][s][23] = 0;
  }
  rebuildAll();
}

// ---------- Sending to the computer ----------
void sendShortcut(uint8_t mods, uint8_t key) {
  if (!hidEnabled) return;
  if (mods & KM_CTRL)  Keyboard.press(KEY_LEFT_CTRL);
  if (mods & KM_SHIFT) Keyboard.press(KEY_LEFT_SHIFT);
  if (mods & KM_ALT)   Keyboard.press(KEY_LEFT_ALT);
  if (mods & KM_GUI)   Keyboard.press(KEY_LEFT_GUI);
  Keyboard.press(key);
  delay(15);
  Keyboard.releaseAll();
}

void sendConsumer(uint16_t code) {
  if (!hidEnabled) return;
  ConsumerControl.press(code);
  delay(5);
  ConsumerControl.release();
  delay(5);
}

// Runs whatever is assigned to a slot for the current operating system
void fireSlot(uint8_t slot) {
  uint8_t h = cfg.host;
  if (bType[h][slot] == TYPE_KEY)        sendShortcut(bMods[h][slot], (uint8_t)bCode[h][slot]);
  else if (bType[h][slot] == TYPE_MEDIA) sendConsumer(bCode[h][slot]);
}

// ---------- OLED ----------
const int SDA_PIN = 4;
const int SCL_PIN = 5;
#define SCREEN_W  128
#define SCREEN_H  64
#define OLED_ADDR 0x3C              // some modules use 0x3D

const uint32_t SCREEN_MAGIC = 0x53435231; // SCR1, stored separately from macro config
ScreenDesign screenDesign;
ScreenDesign screenDraft;
struct ScreenPageData { char name[21]; ScreenDesign design; };
struct ScreenPageStore { uint32_t magic; uint8_t count; ScreenPageData pages[8]; };
// ESP32 layout: ScreenDesign=232 B, page=256 B, eight-page NVS blob=2056 B.
static_assert(sizeof(ScreenPageStore) <= 2304, "OLED page collection exceeds the reserved NVS budget");
const uint32_t SCREEN_PAGES_MAGIC = 0x53435232; // SCR2
ScreenPageStore screenPages;
ScreenPageStore screenPagesDraft;
uint8_t currentScreenPage = 0;
bool screenPagesDraftOpen = false;
bool screenCustom = false;
bool screenDraftOpen = false;
bool validateScreenDesign(const ScreenDesign& design);

bool validateScreenPageName(const char* name) {
  size_t length = strnlen(name, 21);
  if (!length || length > 20) return false;
  for (size_t i = 0; i < length; i++) if (name[i] < 32 || name[i] > 126) return false;
  return true;
}

void setDefaultScreenDesign(ScreenDesign& design) {
  memset(&design, 0, sizeof(design));
  design.magic = SCREEN_MAGIC;
  design.count = 6;
  const uint8_t xs[6] = {4, 74, 72, 72, 72, 72};
  const uint8_t ys[6] = {1, 2, 20, 31, 44, 55};
  const uint8_t bindings[6] = {SCREEN_KEYGRID, SCREEN_HOST, SCREEN_STATIC, SCREEN_LAST, SCREEN_ENCODER, SCREEN_HID};
  const bool inverse[6] = {false, true, false, false, false, false};
  const char* texts[6] = {"", "", "Last:", "", "", ""};
  for (uint8_t i = 0; i < 6; i++) {
    ScreenElement& item = design.elements[i];
    item.x = xs[i]; item.y = ys[i]; item.size = 1;
    item.binding = bindings[i]; item.alignment = SCREEN_LEFT; item.inverse = inverse[i];
    strncpy(item.text, texts[i], sizeof(item.text) - 1);
  }
}

void loadScreenDesign() {
  screenCustom = false;
  memset(&screenPages, 0, sizeof(screenPages));
  screenPages.magic = SCREEN_PAGES_MAGIC; screenPages.count = 1;
  strcpy(screenPages.pages[0].name, "Page 1"); setDefaultScreenDesign(screenPages.pages[0].design);
  size_t stored = prefs.getBytesLength("scrn");
  if (stored == sizeof(screenPages) && prefs.getBytes("scrn", &screenPagesDraft, sizeof(screenPagesDraft)) == sizeof(screenPagesDraft) &&
      screenPagesDraft.magic == SCREEN_PAGES_MAGIC && screenPagesDraft.count >= 1 && screenPagesDraft.count <= 8) {
    bool valid = true;
    for (uint8_t i = 0; i < screenPagesDraft.count; i++) {
      if (!validateScreenPageName(screenPagesDraft.pages[i].name) || !validateScreenDesign(screenPagesDraft.pages[i].design)) valid = false;
    }
    if (valid) { screenPages = screenPagesDraft; screenCustom = true; currentScreenPage = 0; }
  } else if (stored == sizeof(screenDesign)) {
    prefs.getBytes("scrn", &screenDesign, sizeof(screenDesign));
    if (screenDesign.magic == SCREEN_MAGIC && validateScreenDesign(screenDesign)) {
      screenCustom = true; screenPages.magic = SCREEN_PAGES_MAGIC; screenPages.count = 1;
      strcpy(screenPages.pages[0].name, "Page 1"); screenPages.pages[0].design = screenDesign;
    }
  }
}

bool validateScreenDesign(const ScreenDesign& design) {
  if (design.count > 8) return false;
  for (uint8_t i = 0; i < design.count; i++) {
    const ScreenElement& item = design.elements[i];
    if (item.x >= SCREEN_W || item.y >= SCREEN_H || (item.size != 1 && item.size != 2) ||
        item.binding > SCREEN_KEYGRID || item.alignment > SCREEN_RIGHT) return false;
    if (item.binding == SCREEN_KEYGRID) {
      if (item.size != 1 || item.inverse || item.alignment != SCREEN_LEFT || item.x + 62 > SCREEN_W || item.y + 62 > SCREEN_H) return false;
      continue;
    }
    size_t length = strnlen(item.text, sizeof(item.text));
    if (length >= sizeof(item.text)) return false;
    for (size_t n = 0; n < length; n++) if (item.text[n] < 32 || item.text[n] > 126) return false;
    const char* shown = item.text;
    if (item.binding == SCREEN_HOST) shown = "Omarchy";
    else if (item.binding == SCREEN_LAST || item.binding == SCREEN_ENCODER) shown = "WWWWWWWW";
    else if (item.binding == SCREEN_HID) shown = "HID OFF";
    int16_t width = (int16_t)strlen(shown) * 6 * item.size;
    int16_t left = item.x;
    if (item.alignment == SCREEN_CENTER) left -= width / 2;
    else if (item.alignment == SCREEN_RIGHT) left -= width;
    if (left < 0 || left + width > SCREEN_W || item.y + (8 * item.size) > SCREEN_H) return false;
  }
  return true;
}

Adafruit_SSD1306 display(SCREEN_W, SCREEN_H, &Wire, -1);
bool oledOk = false;
bool needRedraw = true;
int8_t lastSlot = -1;               // -1 = nothing pressed yet
const char* encMsg = "";            // short message from the knob
uint32_t encMsgUntil = 0;

void showEncMsg(const char* msg) {
  encMsg = msg;
  encMsgUntil = millis() + 1500;
  needRedraw = true;
}

void drawScreen() {
  display.clearDisplay();

  if (screenCustom) {
    const ScreenDesign& activeDesign = screenPages.pages[currentScreenPage].design;
    for (uint8_t i = 0; i < activeDesign.count; i++) {
      const ScreenElement& item = activeDesign.elements[i];
      if (item.binding == SCREEN_KEYGRID) {
        for (uint8_t r = 0; r < ROWS; r++) {
          for (uint8_t c = 0; c < COLS; c++) {
            int x = item.x + c * 22;
            int y = item.y + r * 22;
            if (keyState[r][c]) display.fillRoundRect(x, y, 18, 18, 3, SSD1306_WHITE);
            else display.drawRoundRect(x, y, 18, 18, 3, SSD1306_WHITE);
          }
        }
        continue;
      }
      const char* value = item.text;
      switch (item.binding) {
        case SCREEN_HOST: value = HOST_NAMES[cfg.host]; break;
        case SCREEN_LAST: value = lastSlot >= 0 ? cfg.labels[lastSlot] : "--"; break;
        case SCREEN_ENCODER: value = encMsg; break;
        case SCREEN_HID: value = hidEnabled ? "" : "HID OFF"; break;
        default: break;
      }
      if (!value[0]) continue;
      display.setTextSize(item.size);
      display.setTextColor(item.inverse ? SSD1306_BLACK : SSD1306_WHITE,
                           item.inverse ? SSD1306_WHITE : SSD1306_BLACK);
      int16_t width = (int16_t)strlen(value) * 6 * item.size;
      int16_t x = item.x;
      if (item.alignment == SCREEN_CENTER) x -= width / 2;
      else if (item.alignment == SCREEN_RIGHT) x -= width;
      display.setCursor(x, item.y);
      display.print(value);
    }
    display.display();
    return;
  }

  // 3x3 grid: filled = pressed
  for (uint8_t r = 0; r < ROWS; r++) {
    for (uint8_t c = 0; c < COLS; c++) {
      int x = 4 + c * 22;
      int y = 1 + r * 22;
      if (keyState[r][c]) display.fillRoundRect(x, y, 18, 18, 3, SSD1306_WHITE);
      else                display.drawRoundRect(x, y, 18, 18, 3, SSD1306_WHITE);
    }
  }

  // OS badge (inverted)
  display.fillRoundRect(72, 1, 54, 12, 2, SSD1306_WHITE);
  display.setTextSize(1);
  display.setTextColor(SSD1306_BLACK);
  display.setCursor(76, 3);
  display.print(HOST_NAMES[cfg.host]);

  display.setTextColor(SSD1306_WHITE);
  display.setCursor(72, 20);
  display.print("Last:");
  display.setCursor(72, 31);
  display.print(lastSlot >= 0 ? cfg.labels[lastSlot] : "--");

  display.setCursor(72, 44);
  display.print(encMsg);

  if (!hidEnabled) {
    display.setCursor(72, 55);
    display.print("HID OFF");
  }

  display.display();
}

void onKeyEvent(uint8_t key, bool pressed) {
  needRedraw = true;                // the grid changes on press and release
  if (!pressed) return;             // shortcuts fire on press only

  if (key == 9 && screenCustom && screenPages.count > 1) {
    currentScreenPage = (currentScreenPage + 1) % screenPages.count;
    needRedraw = true;
    return;                          // SW9 is the on-device page switch while multiple pages exist
  }

  lastSlot = key - 1;
  Serial.printf("SW%u -> %s [%s] (%s)\n", key, cfg.labels[lastSlot],
                cfg.combos[cfg.host][lastSlot], HOST_NAMES[cfg.host]);
  fireSlot(lastSlot);
}

// Actively drain leftover charge on the columns. Without this, a key held in
// the previous row can be read again as a ghost key in the next row.
void dischargeColumns() {
  for (uint8_t c = 0; c < COLS; c++) {
    pinMode(colPins[c], OUTPUT);
    digitalWrite(colPins[c], LOW);
  }
  delayMicroseconds(10);
  for (uint8_t c = 0; c < COLS; c++) {
    pinMode(colPins[c], INPUT_PULLDOWN);
  }
}

// ---------- Encoder logic ----------
void onEncoderShortPress() {
  Serial.printf("Knob: %s\n", cfg.labels[SLOT_PRESS]);
  fireSlot(SLOT_PRESS);
  showEncMsg(cfg.labels[SLOT_PRESS]);
}

void onEncoderLongPress() {
  cfg.host = (cfg.host + 1) % HOST_COUNT;
  markDirty();
  Serial.printf("OS changed to %s\n", HOST_NAMES[cfg.host]);
  needRedraw = true;
}

void pollEncoderButton() {
  bool raw = (digitalRead(ENC_SW) == LOW);   // active LOW (pull-up)
  uint32_t now = millis();

  if (raw != btnLastRaw) {
    btnLastRaw = raw;
    btnLastChange = now;
  } else if (raw != btnState && (now - btnLastChange) >= DEBOUNCE_MS) {
    btnState = raw;
    if (btnState) {
      btnPressedAt = now;
      longFired = false;
    } else if (!longFired) {
      onEncoderShortPress();                 // released before the long-press time
    }
  }

  if (btnState && !longFired && (now - btnPressedAt) >= LONG_PRESS_MS) {
    longFired = true;
    onEncoderLongPress();
  }
}

void pollEncoderPosition() {
  int32_t pos = encPos;
  int32_t d = pos - lastPos;
  if (d == 0) return;
  lastPos = pos;

  uint8_t slot = (d > 0) ? SLOT_CW : SLOT_CCW;
  int32_t n = abs(d);
  if (n > 10) n = 10;
  for (int32_t i = 0; i < n; i++) fireSlot(slot);

  Serial.printf("Knob: %s\n", cfg.labels[slot]);
  showEncMsg(cfg.labels[slot]);
}

// ---------- Commands ----------
int parseSlot(const char* t) {
  if (t[0] >= '1' && t[0] <= '9' && t[1] == 0) return t[0] - '1';
  if (!strcmp(t, "CW")) return SLOT_CW;
  if (!strcmp(t, "CCW")) return SLOT_CCW;
  if (!strcmp(t, "PRESS")) return SLOT_PRESS;
  return -1;
}

int parseHost(const char* t) {
  for (uint8_t i = 0; i < HOST_COUNT; i++) {
    if (!strcmp(t, HOST_IDS[i])) return i;
  }
  if (!strcmp(t, "WIN")) return HOST_WINDOWS;
  if (!strcmp(t, "MAC")) return HOST_MACOS;
  if (!strcmp(t, "ALL")) return HOST_ALL;
  return -1;
}

void slotId(uint8_t slot, char* buf) {
  if (slot < 9) { buf[0] = '1' + slot; buf[1] = 0; }
  else strcpy(buf, slot == SLOT_CW ? "CW" : (slot == SLOT_CCW ? "CCW" : "PRESS"));
}

uint8_t parseScreenBinding(const char* value) {
  if (!strcmp(value, "STATIC")) return SCREEN_STATIC;
  if (!strcmp(value, "HOST")) return SCREEN_HOST;
  if (!strcmp(value, "LAST")) return SCREEN_LAST;
  if (!strcmp(value, "ENCODER")) return SCREEN_ENCODER;
  if (!strcmp(value, "HID")) return SCREEN_HID;
  if (!strcmp(value, "KEYGRID")) return SCREEN_KEYGRID;
  return 255;
}

uint8_t parseScreenAlignment(const char* value) {
  if (!strcmp(value, "LEFT")) return SCREEN_LEFT;
  if (!strcmp(value, "CENTER")) return SCREEN_CENTER;
  if (!strcmp(value, "RIGHT")) return SCREEN_RIGHT;
  return 255;
}

int8_t screenHexDigit(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}

bool decodeScreenText(const char* encoded, char* output, size_t capacity) {
  if (!strcmp(encoded, "-")) { output[0] = 0; return true; }
  size_t length = strlen(encoded);
  if ((length & 1) || length / 2 >= capacity) return false;
  for (size_t i = 0; i < length; i += 2) {
    int8_t high = screenHexDigit(encoded[i]), low = screenHexDigit(encoded[i + 1]);
    if (high < 0 || low < 0) return false;
    char ch = (char)((high << 4) | low);
    if (ch < 32 || ch > 126) return false;
    output[i / 2] = ch;
  }
  output[length / 2] = 0;
  return true;
}

bool parseScreenItem(Stream& out, char* args, ScreenDesign& target) {
  char* fields[7];
  for (uint8_t i = 0; i < 7; i++) fields[i] = nextToken(&args);
  while (*args == ' ' || *args == '\t') args++;
  if (!fields[0] || !fields[1] || !fields[2] || !fields[3] || !fields[4] || !fields[5] || !fields[6] || !*args) {
    out.println("ERR usage: ITEM index x y size mode binding alignment text"); return false;
  }
  uint8_t index = (uint8_t)atoi(fields[0]);
  uint16_t x = (uint16_t)atoi(fields[1]), y = (uint16_t)atoi(fields[2]);
  uint8_t size = (uint8_t)atoi(fields[3]);
  upperInPlace(fields[4]); upperInPlace(fields[5]); upperInPlace(fields[6]);
  uint8_t binding = parseScreenBinding(fields[5]), alignment = parseScreenAlignment(fields[6]);
  if (index != target.count || index >= 8 || x >= SCREEN_W || y >= SCREEN_H ||
      (size != 1 && size != 2) || binding == 255 || alignment == 255 ||
      (strcmp(fields[4], "NORMAL") && strcmp(fields[4], "INVERSE")) || strlen(args) > 42) {
    out.println("ERR invalid screen item"); return false;
  }
  ScreenElement& item = target.elements[index];
  item.x = x; item.y = y; item.size = size; item.binding = binding; item.alignment = alignment;
  item.inverse = !strcmp(fields[4], "INVERSE");
  if (!decodeScreenText(args, item.text, sizeof(item.text))) { out.println("ERR invalid screen text encoding"); return false; }
  target.count++;
  if (!validateScreenDesign(target)) { target.count--; out.println("ERR invalid screen item bounds"); return false; }
  return true;
}

void dumpScreenDesign(Stream& out) {
  if (!screenCustom) {
    out.println("SCREEN LEGACY");
    out.println("SCREEN END");
    return;
  }
  const ScreenDesign& activeDesign = screenPages.pages[currentScreenPage].design;
  for (uint8_t i = 0; i < activeDesign.count; i++) {
    const ScreenElement& item = activeDesign.elements[i];
    const char* mode = item.inverse ? "INVERSE" : "NORMAL";
    const char* binding = item.binding == SCREEN_HOST ? "HOST" : item.binding == SCREEN_LAST ? "LAST" :
      item.binding == SCREEN_ENCODER ? "ENCODER" : item.binding == SCREEN_HID ? "HID" :
      item.binding == SCREEN_KEYGRID ? "KEYGRID" : "STATIC";
    const char* alignment = item.alignment == SCREEN_CENTER ? "CENTER" : item.alignment == SCREEN_RIGHT ? "RIGHT" : "LEFT";
    out.printf("SCREEN ITEM %u %u %u %u %s %s %s ", i, item.x, item.y, item.size,
      mode, binding, alignment);
    if (item.text[0]) {
      for (size_t n = 0; item.text[n]; n++) out.printf("%02x", (uint8_t)item.text[n]);
    } else out.print("-");
    out.println();
  }
  out.println("SCREEN END");
}

void dumpScreenPages(Stream& out) {
  out.printf("SCREEN PAGES %u\nSCREEN CURRENT %u\n", screenPages.count, currentScreenPage);
  for (uint8_t p = 0; p < screenPages.count; p++) {
    out.printf("SCREEN PAGE %u ", p);
    if (screenPages.pages[p].name[0]) for (size_t n = 0; screenPages.pages[p].name[n]; n++) out.printf("%02x", (uint8_t)screenPages.pages[p].name[n]);
    else out.print("-");
    out.println();
    const ScreenDesign& design = screenPages.pages[p].design;
    for (uint8_t i = 0; i < design.count; i++) {
      const ScreenElement& item = design.elements[i];
      const char* mode = item.inverse ? "INVERSE" : "NORMAL";
      const char* binding = item.binding == SCREEN_HOST ? "HOST" : item.binding == SCREEN_LAST ? "LAST" : item.binding == SCREEN_ENCODER ? "ENCODER" : item.binding == SCREEN_HID ? "HID" : item.binding == SCREEN_KEYGRID ? "KEYGRID" : "STATIC";
      const char* alignment = item.alignment == SCREEN_CENTER ? "CENTER" : item.alignment == SCREEN_RIGHT ? "RIGHT" : "LEFT";
      out.printf("SCREEN ITEM %u %u %u %u %s %s %s ", i, item.x, item.y, item.size, mode, binding, alignment);
      if (item.text[0]) for (size_t n = 0; item.text[n]; n++) out.printf("%02x", (uint8_t)item.text[n]); else out.print("-");
      out.println();
    }
    out.println("SCREEN PAGE END");
  }
  out.println("SCREEN END");
}

void handleScreenCommand(Stream& out, char* args) {
  char* sub = nextToken(&args);
  if (!sub) { out.println("ERR usage: SCREEN GET|BEGIN|CLEAR|ITEM|VALIDATE|COMMIT"); return; }
  upperInPlace(sub);

  if (!strcmp(sub, "PAGES")) {
    char* action = nextToken(&args);
    if (!action) { out.println("ERR usage: SCREEN PAGES GET|BEGIN|CLEAR|VALIDATE|COMMIT"); return; }
    upperInPlace(action);
    if (!strcmp(action, "GET")) { dumpScreenPages(out); return; }
    if (!strcmp(action, "BEGIN")) {
      memset(&screenPagesDraft, 0, sizeof(screenPagesDraft)); screenPagesDraft.magic = SCREEN_PAGES_MAGIC;
      if (screenCustom) screenPagesDraft = screenPages;
      else { screenPagesDraft.count = 1; strcpy(screenPagesDraft.pages[0].name, "Page 1"); setDefaultScreenDesign(screenPagesDraft.pages[0].design); }
      screenPagesDraftOpen = true; out.println("OK SCREEN PAGES BEGIN"); return;
    }
    if (!screenPagesDraftOpen) { out.println("ERR SCREEN PAGES BEGIN required"); return; }
    if (!strcmp(action, "CLEAR")) { memset(&screenPagesDraft, 0, sizeof(screenPagesDraft)); screenPagesDraft.magic = SCREEN_PAGES_MAGIC; out.println("OK SCREEN PAGES CLEAR"); return; }
    if (!strcmp(action, "VALIDATE")) {
      bool valid = screenPagesDraft.count >= 1 && screenPagesDraft.count <= 8;
      for (uint8_t p = 0; valid && p < screenPagesDraft.count; p++) valid = validateScreenPageName(screenPagesDraft.pages[p].name) && validateScreenDesign(screenPagesDraft.pages[p].design);
      out.println(valid ? "OK SCREEN PAGES VALID" : "ERR invalid screen pages"); return;
    }
    if (!strcmp(action, "COMMIT")) {
      bool valid = screenPagesDraft.count >= 1 && screenPagesDraft.count <= 8;
      for (uint8_t p = 0; valid && p < screenPagesDraft.count; p++) valid = validateScreenPageName(screenPagesDraft.pages[p].name) && validateScreenDesign(screenPagesDraft.pages[p].design);
      if (!valid) { out.println("ERR invalid screen pages"); return; }
      screenPagesDraft.magic = SCREEN_PAGES_MAGIC;
      if (prefs.putBytes("scrn", &screenPagesDraft, sizeof(screenPagesDraft)) != sizeof(screenPagesDraft)) { out.println("ERR screen storage failed"); return; }
      screenPages = screenPagesDraft; screenCustom = true; currentScreenPage = 0; screenPagesDraftOpen = false; screenDraftOpen = false; needRedraw = true;
      out.println("OK SCREEN PAGES COMMITTED"); return;
    }
    out.println("ERR unknown SCREEN PAGES command"); return;
  }
  if (!strcmp(sub, "PAGE")) {
    char* action = nextToken(&args);
    if (!action) { out.println("ERR usage: SCREEN PAGE ADD|ITEM"); return; }
    upperInPlace(action);
    if (!strcmp(action, "SET")) {
      char* pageText = nextToken(&args); int pageIndex = pageText ? atoi(pageText) : -1;
      if (!screenCustom || pageIndex < 0 || pageIndex >= screenPages.count) { out.println("ERR invalid page index"); return; }
      currentScreenPage = (uint8_t)pageIndex; needRedraw = true; out.println("OK SCREEN PAGE SELECTED"); return;
    }
    if (!screenPagesDraftOpen) { out.println("ERR SCREEN PAGES BEGIN required"); return; }
    if (!strcmp(action, "ADD")) {
      char* indexText = nextToken(&args); char* nameText = nextToken(&args);
      if (!indexText || !nameText || screenPagesDraft.count >= 8 || atoi(indexText) != screenPagesDraft.count) { out.println("ERR invalid page index"); return; }
      ScreenPageData& page = screenPagesDraft.pages[screenPagesDraft.count];
      if (!decodeScreenText(nameText, page.name, sizeof(page.name)) || !page.name[0]) { out.println("ERR invalid page name"); return; }
      memset(&page.design, 0, sizeof(page.design)); page.design.magic = SCREEN_MAGIC; screenPagesDraft.count++; out.println("OK SCREEN PAGE ADDED"); return;
    }
    if (!strcmp(action, "ITEM")) {
      char* pageText = nextToken(&args);
      if (!pageText) { out.println("ERR missing page index"); return; }
      int pageIndex = atoi(pageText);
      if (pageIndex < 0 || pageIndex >= screenPagesDraft.count) { out.println("ERR invalid page index"); return; }
      if (!parseScreenItem(out, args, screenPagesDraft.pages[pageIndex].design)) return;
      out.println("OK SCREEN PAGE ITEM"); return;
    }
    out.println("ERR unknown SCREEN PAGE command"); return;
  }

  if (!strcmp(sub, "GET")) {
    dumpScreenDesign(out);
  } else if (!strcmp(sub, "BEGIN")) {
    if (screenCustom) screenDraft = screenPages.pages[currentScreenPage].design;
    else setDefaultScreenDesign(screenDraft);
    screenDraftOpen = true;
    out.println("OK SCREEN BEGIN");
  } else if (!strcmp(sub, "CLEAR")) {
    if (!screenDraftOpen) { out.println("ERR SCREEN BEGIN required"); return; }
    memset(&screenDraft, 0, sizeof(screenDraft));
    screenDraft.magic = SCREEN_MAGIC;
    out.println("OK SCREEN CLEAR");
  } else if (!strcmp(sub, "ITEM")) {
    if (!screenDraftOpen) { out.println("ERR SCREEN BEGIN required"); return; }
    char* fields[7];
    for (uint8_t i = 0; i < 7; i++) fields[i] = nextToken(&args);
    while (*args == ' ' || *args == '\t') args++;
    if (!fields[0] || !fields[1] || !fields[2] || !fields[3] || !fields[4] || !fields[5] || !fields[6] || !*args) {
      out.println("ERR usage: SCREEN ITEM index x y size mode binding alignment text"); return;
    }
    uint8_t index = (uint8_t)atoi(fields[0]);
    uint16_t x = (uint16_t)atoi(fields[1]);
    uint16_t y = (uint16_t)atoi(fields[2]);
    uint8_t size = (uint8_t)atoi(fields[3]);
    upperInPlace(fields[4]); upperInPlace(fields[5]); upperInPlace(fields[6]);
    uint8_t binding = parseScreenBinding(fields[5]);
    uint8_t alignment = parseScreenAlignment(fields[6]);
    if (index != screenDraft.count || index >= 8 || x >= SCREEN_W || y >= SCREEN_H ||
        (size != 1 && size != 2) || binding == 255 || alignment == 255 ||
        (strcmp(fields[4], "NORMAL") && strcmp(fields[4], "INVERSE")) ||
        (strcmp(args, "-") && (strlen(args) > 42 || strlen(args) % 2 != 0))) {
      out.println("ERR invalid screen item"); return;
    }
    ScreenElement& item = screenDraft.elements[index];
    item.x = x; item.y = y; item.size = size; item.binding = binding; item.alignment = alignment;
    item.inverse = !strcmp(fields[4], "INVERSE");
    if (!strcmp(args, "-")) item.text[0] = 0;
    else {
      size_t encodedLength = strlen(args);
      for (size_t i = 0; i < encodedLength; i += 2) {
        int8_t high = screenHexDigit(args[i]);
        int8_t low = screenHexDigit(args[i + 1]);
        if (high < 0 || low < 0) { out.println("ERR invalid screen text encoding"); return; }
        char ch = (char)((high << 4) | low);
        if (ch < 32 || ch > 126) { out.println("ERR text must be printable ASCII"); return; }
        item.text[i / 2] = ch;
      }
      item.text[encodedLength / 2] = 0;
    }
    screenDraft.count++;
    out.println("OK SCREEN ITEM");
  } else if (!strcmp(sub, "VALIDATE")) {
    if (!screenDraftOpen || !validateScreenDesign(screenDraft)) { out.println("ERR invalid screen design"); return; }
    out.println("OK SCREEN VALID");
  } else if (!strcmp(sub, "COMMIT")) {
    if (!screenDraftOpen || !validateScreenDesign(screenDraft)) { out.println("ERR invalid screen design"); return; }
    screenDraft.magic = SCREEN_MAGIC;
    if (prefs.putBytes("scrn", &screenDraft, sizeof(screenDraft)) != sizeof(screenDraft)) {
      out.println("ERR screen storage failed"); return;
    }
    screenDesign = screenDraft;
    memset(&screenPages, 0, sizeof(screenPages)); screenPages.magic = SCREEN_PAGES_MAGIC; screenPages.count = 1;
    strcpy(screenPages.pages[0].name, "Page 1"); screenPages.pages[0].design = screenDraft; currentScreenPage = 0;
    screenCustom = true;
    screenDraftOpen = false;
    needRedraw = true;
    out.println("OK SCREEN COMMITTED");
  } else {
    out.println("ERR unknown SCREEN command");
  }
}

// The output is made of valid commands, so it can be pasted back to restore it
void dumpConfig(Stream& out) {
  char id[8];
  out.printf("HOST %s\n", HOST_IDS[cfg.host]);
  for (uint8_t s = 0; s < SLOT_COUNT; s++) {
    slotId(s, id);
    out.printf("LABEL %s %s\n", id, cfg.labels[s]);
  }
  for (uint8_t h = 0; h < HOST_COUNT; h++) {
    for (uint8_t s = 0; s < SLOT_COUNT; s++) {
      slotId(s, id);
      out.printf("SET %s %s %s\n", id, HOST_IDS[h], cfg.combos[h][s]);
    }
  }
  out.println("END");
}

void handleCommand(Stream& out, char* line) {
  char* p = line;
  char* cmd = nextToken(&p);
  if (!cmd) return;
  upperInPlace(cmd);

  if (!strcmp(cmd, "SCREEN")) {
    handleScreenCommand(out, p);
  } else if (!strcmp(cmd, "HELLO")) {
    out.println("OK MACROPAD 2");

  } else if (!strcmp(cmd, "GET")) {
    dumpConfig(out);

  } else if (!strcmp(cmd, "SAVE")) {
    saveConfig();
    cfgDirty = false;
    out.println("OK saved");

  } else if (!strcmp(cmd, "RESET")) {
    uint8_t keepHost = cfg.host;
    loadDefaults();
    cfg.host = keepHost;
    rebuildAll();
    saveConfig();
    cfgDirty = false;
    needRedraw = true;
    out.println("OK reset to defaults");

  } else if (!strcmp(cmd, "HOST")) {
    char* o = nextToken(&p);
    int h = -1;
    if (o) { upperInPlace(o); h = parseHost(o); }
    if (h < 0 || h >= HOST_COUNT) {
      out.println("ERR usage: HOST WINDOWS|LINUX|MACOS|OMARCHY");
      return;
    }
    cfg.host = h;
    markDirty();
    needRedraw = true;
    out.println("OK");

  } else if (!strcmp(cmd, "LABEL")) {
    char* s = nextToken(&p);
    int slot = -1;
    if (s) { upperInPlace(s); slot = parseSlot(s); }
    while (*p == ' ' || *p == '\t') p++;
    if (slot < 0 || *p == 0) {
      out.println("ERR usage: LABEL <slot> <text, up to 8 characters>");
      return;
    }
    memset(cfg.labels[slot], 0, 9);
    for (uint8_t i = 0; i < 8 && p[i]; i++) {
      char ch = p[i];
      cfg.labels[slot][i] = (ch >= 32 && ch < 127) ? ch : '?';   // the screen font is ASCII only
    }
    markDirty();
    needRedraw = true;
    out.println("OK");

  } else if (!strcmp(cmd, "SET")) {
    char* s = nextToken(&p);
    char* o = nextToken(&p);
    char* c = nextToken(&p);
    int slot = -1;
    int h = -1;
    if (s) { upperInPlace(s); slot = parseSlot(s); }
    if (o) { upperInPlace(o); h = parseHost(o); }
    if (slot < 0 || h < 0 || !c) {
      out.println("ERR usage: SET <slot> <os|ALL> <combo>");
      return;
    }
    upperInPlace(c);
    uint8_t t, m;
    uint16_t k;
    if (strlen(c) > 23 || !parseCombo(c, &t, &m, &k)) {
      out.println("ERR bad combo");
      return;
    }
    if (h == HOST_ALL) {
      for (uint8_t i = 0; i < HOST_COUNT; i++) applyCombo(i, slot, c);
    } else {
      applyCombo(h, slot, c);
    }
    markDirty();
    out.println("OK");

  } else {
    out.println("ERR unknown command");
  }
}

// ---------- Reading command lines from a serial port ----------
char lineBuf[2][96];
uint8_t lineLen[2] = {0, 0};

void pollStream(Stream& s, uint8_t id) {
  while (s.available()) {
    char c = (char)s.read();
    if (c == '\r' || c == '\n') {
      if (lineLen[id] > 0) {
        lineBuf[id][lineLen[id]] = 0;
        lineLen[id] = 0;
        handleCommand(s, lineBuf[id]);
      }
    } else if (lineLen[id] < sizeof(lineBuf[id]) - 1) {
      lineBuf[id][lineLen[id]++] = c;
    }
  }
}

void setup() {
  Serial.begin(115200);

  for (uint8_t r = 0; r < ROWS; r++) {
    pinMode(rowPins[r], OUTPUT);
    digitalWrite(rowPins[r], LOW);
  }
  for (uint8_t c = 0; c < COLS; c++) {
    pinMode(colPins[c], INPUT_PULLDOWN);
  }

  pinMode(ENC_CLK, INPUT_PULLUP);
  pinMode(ENC_DT, INPUT_PULLUP);
  pinMode(ENC_SW, INPUT_PULLUP);
  delay(20);                                       // let the pull-up settle
  hidEnabled = (digitalRead(ENC_SW) == HIGH);      // knob held at power-up = safe mode

  encState = (digitalRead(ENC_CLK) << 1) | digitalRead(ENC_DT);
  attachInterrupt(digitalPinToInterrupt(ENC_CLK), encoderISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_DT), encoderISR, CHANGE);

  prefs.begin("macropad", false);
  loadConfig();
  loadScreenDesign();

  if (hidEnabled) {
    Keyboard.begin();
    ConsumerControl.begin();
    AppSerial.begin();
    USB.productName("3x3 Macropad");
    USB.begin();
  } else {
    Serial.println("SAFE MODE: USB keyboard is disabled");
  }

  Wire.begin(SDA_PIN, SCL_PIN);
  Wire.setClock(400000);
  oledOk = display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR);
  if (!oledOk) Serial.println("SSD1306 not found, check wiring/address");

  display.setRotation(2);           // flip the screen upside down (180 degrees)
  Serial.println("Ready. Send HELLO or GET");
}

void loop() {
  for (uint8_t r = 0; r < ROWS; r++) {
    dischargeColumns();
    digitalWrite(rowPins[r], HIGH);
    delayMicroseconds(20);          // let the line settle

    for (uint8_t c = 0; c < COLS; c++) {
      bool raw = digitalRead(colPins[c]);
      uint32_t now = millis();

      if (raw != lastRaw[r][c]) {
        lastRaw[r][c] = raw;
        lastChange[r][c] = now;
      } else if (raw != keyState[r][c] && (now - lastChange[r][c]) >= DEBOUNCE_MS) {
        keyState[r][c] = raw;
        onKeyEvent(r * COLS + c + 1, raw);
      }
    }

    digitalWrite(rowPins[r], LOW);
  }

  pollEncoderButton();
  pollEncoderPosition();

  pollStream(Serial, 0);                         // commands from the COM port
  if (hidEnabled) pollStream(AppSerial, 1);      // commands from the USB port (the app)

  if (cfgDirty && (millis() - cfgDirtyAt) > 2000) {
    saveConfig();
    cfgDirty = false;
  }

  if (encMsg[0] != '\0' && (int32_t)(millis() - encMsgUntil) >= 0) {
    encMsg = "";
    needRedraw = true;
  }

  if (needRedraw && oledOk) {
    needRedraw = false;
    drawScreen();
  }
}
