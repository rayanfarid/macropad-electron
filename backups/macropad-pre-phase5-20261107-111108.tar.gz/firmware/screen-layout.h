#ifndef MACROPAD_SCREEN_LAYOUT_H
#define MACROPAD_SCREEN_LAYOUT_H

#include <stdint.h>

enum ScreenBinding : uint8_t { SCREEN_STATIC, SCREEN_HOST, SCREEN_LAST, SCREEN_ENCODER, SCREEN_HID, SCREEN_KEYGRID };
enum ScreenAlignment : uint8_t { SCREEN_LEFT, SCREEN_CENTER, SCREEN_RIGHT };

struct ScreenElement {
  uint8_t x, y, size, binding, alignment;
  bool inverse;
  char text[22];
};

struct ScreenDesign {
  uint32_t magic;
  uint8_t count;
  ScreenElement elements[8];
};

#endif
