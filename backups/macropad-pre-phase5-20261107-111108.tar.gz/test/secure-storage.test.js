const test = require("node:test");
const assert = require("node:assert/strict");
const {
  configureLinuxPasswordStore,
  secureCredentialStorageStatus
} = require("../secure-storage");

test("Linux password-store switch prefers gnome-libsecret before app ready", () => {
  const switches = [];
  const app = { commandLine: { appendSwitch: (name, value) => switches.push([name, value]) } };
  assert.deepEqual(configureLinuxPasswordStore(app, "linux"), { applied: true, backendPreference: "gnome-libsecret" });
  assert.deepEqual(switches, [["password-store", "gnome-libsecret"]]);
  assert.deepEqual(configureLinuxPasswordStore(app, "darwin"), { applied: false, reason: "not-linux" });
});

test("Linux basic_text backend is treated as unavailable with actionable help", () => {
  const status = secureCredentialStorageStatus({
    isEncryptionAvailable: () => false,
    getSelectedStorageBackend: () => "basic_text"
  }, "linux");
  assert.equal(status.available, false);
  assert.equal(status.backend, "basic_text");
  assert.match(status.diagnosis, /unavailable/i);
  assert.match(status.help, /gnome-keyring|Secret Service/i);
  assert.doesNotMatch(status.diagnosis, /sk-/);
  assert.doesNotMatch(status.help, /sk-/);
});

test("gnome_libsecret backend is available and never includes secrets", () => {
  const status = secureCredentialStorageStatus({
    isEncryptionAvailable: () => true,
    getSelectedStorageBackend: () => "gnome_libsecret"
  }, "linux");
  assert.equal(status.available, true);
  assert.match(status.label, /gnome-libsecret/);
  assert.equal(status.diagnosis, "Secure storage available.");
  assert.equal(status.help, "");
});
