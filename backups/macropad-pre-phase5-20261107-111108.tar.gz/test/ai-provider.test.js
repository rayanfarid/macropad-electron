const test = require("node:test");
const assert = require("node:assert/strict");
const { createDefaultScreenDesign } = require("../screen-design");
const { SCREEN_AI_INSTRUCTIONS, parseAiDesignResponse } = require("../ai-design");
const {
  testOpenAiConnection,
  generateScreenDesignWithOpenAi,
  buildScreenDesignRequest,
  extractResponsesOutputText,
  formatOpenAiHttpError,
  redactSecrets
} = require("../ai-provider");

const key = `sk-${"a".repeat(32)}`;

function jsonResponse(status, body) {
  return {
    ok: status >= 200 && status < 300,
    status,
    async json() { return body; },
    async text() { return JSON.stringify(body); }
  };
}

test("OpenAI connection test authenticates and verifies the configured model", async () => {
  const calls = [];
  const result = await testOpenAiConnection(key, {
    model: "gpt-4.1-mini",
    fetchImpl: async (url, options) => {
      calls.push({ url, options });
      if (url.endsWith("/models")) return jsonResponse(200, { data: [] });
      if (url.endsWith("/models/gpt-4.1-mini")) return jsonResponse(200, { id: "gpt-4.1-mini" });
      throw new Error(`unexpected url ${url}`);
    }
  });
  assert.equal(result.success, true);
  assert.match(result.message, /gpt-4\.1-mini/);
  assert.equal(calls[0].url, "https://api.openai.com/v1/models");
  assert.equal(calls[0].options.headers.Authorization, `Bearer ${key}`);
  assert.equal(calls[1].url, "https://api.openai.com/v1/models/gpt-4.1-mini");
});

test("invalid, unauthorized, forbidden, and network failures never echo the API key", async () => {
  await assert.rejects(testOpenAiConnection(""), /looks invalid/);
  await assert.rejects(testOpenAiConnection(key, {
    fetchImpl: async () => jsonResponse(401, { error: { message: `bad ${key}`, type: "invalid_request_error" } })
  }), error => {
    assert.match(error.message, /rejected this API key/i);
    assert.doesNotMatch(error.message, new RegExp(key));
    return true;
  });
  await assert.rejects(testOpenAiConnection(key, {
    fetchImpl: async url => {
      if (url.endsWith("/models")) return jsonResponse(200, { data: [] });
      return jsonResponse(403, { error: { message: "no access", type: "access" } });
    }
  }), /rejected the model check/i);
  await assert.rejects(testOpenAiConnection(key, {
    fetchImpl: async () => { throw new Error(key); }
  }), error => {
    assert.match(error.message, /Could not reach OpenAI/);
    assert.doesNotMatch(error.message, new RegExp(key));
    return true;
  });
});

test("Responses request body includes json in input and uses the Responses endpoint", () => {
  const request = buildScreenDesignRequest({
    model: "gpt-4.1-mini",
    instructions: SCREEN_AI_INSTRUCTIONS,
    prompt: "Make page 1 show host status",
    currentDesign: createDefaultScreenDesign()
  });
  assert.equal(request.url, "https://api.openai.com/v1/responses");
  assert.equal(request.method, "POST");
  assert.equal(request.body.model, "gpt-4.1-mini");
  assert.equal(request.body.text.format.type, "json_object");
  assert.match(request.body.input[0].content, /json/i);
  assert.doesNotMatch(JSON.stringify(request.body), new RegExp(key));
  assert.equal(request.headers.Authorization.includes("sk-"), false);
});

test("successful Responses API generation parses output_text through the schema validator", async () => {
  const design = createDefaultScreenDesign();
  const payload = {
    explanation: "Host status page.",
    notes: ["Uses HOST binding."],
    design
  };
  let seenBody;
  const result = await generateScreenDesignWithOpenAi({
    apiKey: key,
    model: "gpt-4.1-mini",
    instructions: SCREEN_AI_INSTRUCTIONS,
    prompt: "Show the current host",
    currentDesign: design,
    parseResponse: parseAiDesignResponse,
    fetchImpl: async (url, options) => {
      assert.equal(url, "https://api.openai.com/v1/responses");
      seenBody = JSON.parse(options.body);
      assert.match(seenBody.input[0].content, /json/i);
      assert.equal(options.headers.Authorization, `Bearer ${key}`);
      return jsonResponse(200, { output_text: JSON.stringify(payload) });
    }
  });
  assert.equal(result.design.pages[0].elements[0].binding, "KEYGRID");
  assert.equal(seenBody.model, "gpt-4.1-mini");
});

test("HTTP 400 with an OpenAI JSON error surfaces the API message and hides secrets", async () => {
  await assert.rejects(generateScreenDesignWithOpenAi({
    apiKey: key,
    model: "gpt-4.1-mini",
    instructions: SCREEN_AI_INSTRUCTIONS,
    prompt: "Make a dashboard",
    currentDesign: createDefaultScreenDesign(),
    parseResponse: parseAiDesignResponse,
    fetchImpl: async () => jsonResponse(400, {
      error: {
        message: `'messages' must contain the word 'json' in some form, to use 'text.format' of type 'json_object'. leaked ${key}`,
        type: "invalid_request_error",
        code: "invalid_request"
      }
    })
  }), error => {
    assert.match(error.message, /OpenAI rejected the screen generation \(HTTP 400, model gpt-4\.1-mini\)/);
    assert.match(error.message, /must contain the word 'json'/i);
    assert.doesNotMatch(error.message, new RegExp(key));
    return true;
  });
});

test("malformed response and missing design text are rejected safely", async () => {
  await assert.rejects(generateScreenDesignWithOpenAi({
    apiKey: key,
    model: "gpt-4.1-mini",
    instructions: SCREEN_AI_INSTRUCTIONS,
    prompt: "Make a dashboard",
    currentDesign: createDefaultScreenDesign(),
    parseResponse: parseAiDesignResponse,
    fetchImpl: async () => ({
      ok: true,
      status: 200,
      async json() { throw new Error("boom"); }
    })
  }), /malformed JSON response/);

  assert.throws(() => extractResponsesOutputText({ output: [] }), /did not contain a design/);
});

test("authentication and model access failures never include the API key", async () => {
  await assert.rejects(generateScreenDesignWithOpenAi({
    apiKey: key,
    model: "gpt-4.1-mini",
    instructions: SCREEN_AI_INSTRUCTIONS,
    prompt: "Make a dashboard",
    currentDesign: createDefaultScreenDesign(),
    parseResponse: parseAiDesignResponse,
    fetchImpl: async () => jsonResponse(401, { error: { message: `Unauthorized ${key}`, type: "invalid_request_error" } })
  }), error => {
    assert.match(error.message, /rejected this API key/i);
    assert.doesNotMatch(error.message, new RegExp(key));
    return true;
  });

  const formatted = formatOpenAiHttpError({
    status: 404,
    message: `The model 'missing-model' does not exist or you do not have access to it ${key}`,
    type: "invalid_request_error",
    code: "model_not_found"
  }, { model: "missing-model", operation: "screen generation" });
  assert.match(formatted, /missing-model/);
  assert.doesNotMatch(formatted, new RegExp(key));
  assert.equal(redactSecrets(`Bearer ${key}`), "Bearer [redacted]");
  assert.equal(redactSecrets(`Authorization: Bearer ${key}`), "Authorization: Bearer [redacted]");
  assert.equal(redactSecrets(key), "[redacted-api-key]");
});
