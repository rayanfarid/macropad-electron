const gemini = require("./gemini");
const openrouter = require("./openrouter");

// Groq is reserved for a later free-tier integration; not selectable yet.
const PROVIDERS = Object.freeze({
  gemini,
  openrouter
});

const PROVIDER_ORDER = Object.freeze(["gemini", "openrouter"]);

function listProviders() {
  return PROVIDER_ORDER.map(id => {
    const provider = PROVIDERS[id];
    return {
      id: provider.id,
      label: provider.label,
      freeOnly: Boolean(provider.freeOnly),
      keyHint: provider.keyHint,
      keyPlaceholder: provider.keyPlaceholder,
      help: provider.help,
      models: provider.FREE_MODELS.map(model => ({ ...model })),
      defaultModel: provider.defaultModel()
    };
  });
}

function getProvider(providerId) {
  const provider = PROVIDERS[providerId];
  if (!provider) throw new Error(`Unsupported AI provider: ${providerId}`);
  return provider;
}

function resolveProviderSelection(providerId, modelId) {
  const provider = getProvider(providerId || "gemini");
  const model = modelId && provider.isFreeModel(modelId) ? modelId : provider.defaultModel();
  provider.assertFreeModel(model);
  return { provider, model };
}

function assertPaidModelRejected(providerId, modelId) {
  const provider = getProvider(providerId);
  if (!provider.isFreeModel(modelId)) {
    provider.assertFreeModel(modelId);
  }
  return true;
}

module.exports = {
  PROVIDERS,
  PROVIDER_ORDER,
  listProviders,
  getProvider,
  resolveProviderSelection,
  assertPaidModelRejected
};
