const { listProviders, getProvider, resolveProviderSelection } = require("./ai/registry");
const { redactSecrets, sanitizeThrownMessage } = require("./ai/common");
const { SCREEN_AI_INSTRUCTIONS } = require("./ai-design");

function getCatalog() {
  return {
    freeOnly: true,
    providers: listProviders(),
    notice: "Only free-tier API models are enabled. Free providers have rate limits and availability can change."
  };
}

async function testProviderConnection({ providerId, model, apiKey, fetchImpl }) {
  const { provider, model: resolvedModel } = resolveProviderSelection(providerId, model);
  return provider.testConnection(apiKey, { model: resolvedModel, fetchImpl });
}

async function generateScreenDesignWithProvider({
  providerId,
  model,
  apiKey,
  prompt,
  currentDesign,
  fetchImpl,
  parseResponse,
  instructions = SCREEN_AI_INSTRUCTIONS
}) {
  const { provider, model: resolvedModel } = resolveProviderSelection(providerId, model);
  return provider.generateScreenDesign({
    apiKey,
    model: resolvedModel,
    instructions,
    prompt,
    currentDesign,
    fetchImpl,
    parseResponse
  });
}

module.exports = {
  getCatalog,
  getProvider,
  resolveProviderSelection,
  testProviderConnection,
  generateScreenDesignWithProvider,
  redactSecrets,
  sanitizeThrownMessage,
  // Compatibility shims used by older tests/docs paths.
  DEFAULT_AI_MODEL: "gemini-2.5-flash-lite"
};
